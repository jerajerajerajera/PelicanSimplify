<x-filament-panels::page>
@assets
<link id="simplify-dashboard-css" rel="stylesheet" href="{{ \Simplify\Panel\Services\BuildInfo::asset('dashboard.css') }}">
<script src="{{ \Simplify\Panel\Services\BuildInfo::asset('dashboard.js') }}"></script>
@endassets
<div class="ps" data-simplify-root x-cloak wire:ignore.self
     x-data="pelicanSimplify($wire, @js($this->initial()))"
     x-on:resize.window.debounce.150ms="applyScale(); restoreOverviewView()"
     :class="{'dark': themeDark, 'server-active': !!server, 'host-mode': hostMode && !server, 'is-embedded': embedded, 'is-console-window': consoleWindow, 'is-full-width': overviewPreferences.fullWidth, 'is-server-full-width': overviewPreferences.serverFullWidth, 'ps-halloween': halloween()}"
     :style="accentStyle(server?.uuid || 'overview')">
    @include('pelican-simplify::dashboard-icons')
    {{-- Halloween (25 October to 2 November): a faint web with a spider in the corner. Clicks pass through. --}}
    <template x-if="halloween()">
        <div class="ps-hw-corner" aria-hidden="true">
            <svg class="ps-hw-web" viewBox="0 0 100 100"><path d="M100 0H0M100 0 10 45M100 0 40 80M100 0V100M100 0 72 95M78 0Q81.1 7 80.2 9.9Q85.5 15.8 86.8 17.6Q92.3 21.3 93.8 20.9Q98.9 23.4 100 22M60 0Q64 11 64 18Q72 27 76 32Q84.4 37 88.8 38Q96.4 41 100 40M40 0Q45 15.5 46 27Q57 39.5 64 48Q75.6 54.5 83.2 57Q93.6 60.5 100 60M20 0Q26 20 28 36Q42 52 52 64Q66.8 72 77.6 76Q90.8 80 100 80"/></svg>
            <span class="ps-hw-spider"><svg viewBox="0 0 14 14"><circle cx="7" cy="7" r="3.2"/><path d="M4 5 1 2M4 7H0M4 9l-3 3M10 5l3-3M10 7h4M10 9l3 3"/></svg></span>
        </div>
    </template>

    <main class="ps-main">
        {{-- Header ------------------------------------------------------------------------------ --}}
        <header class="ps-top">
            <div class="ps-heading">
                <div class="ps-identity">
                    <a :href="boot.list_url"><h1 class="ps-brand" :style="brandStyle()"><template x-if="brand().logo_url && brand().mode === 'logo'"><img class="ps-brand-logo" :src="brand().logo_url" alt="" :style="{ height: (Number(brand().logo_height) || 32) + 'px' }"></template><span class="ps-panel-name" x-show="!(brand().logo_url && brand().mode === 'logo') || brand().logo_text" :style="Simplify.brandTextStyle(brand(), brand().font_stack, boot.appearance?.accent_color)" x-text="(brand().text || '').trim() || boot.panel_name || 'Pelican'"></span><span class="ps-title-pelican" x-show="brand().suffix !== false">× Pelican</span><span class="ps-visually-hidden" x-show="brand().mode === 'logo' && !brand().logo_text" x-text="boot.panel_name || 'Pelican'"></span><template x-if="halloween()"><svg class="ps-hw-lantern" viewBox="0 0 24 24" aria-hidden="true"><path class="ps-hw-body" d="M12 6.5c-1.6-.9-3.6-1-5.3-.2C3.8 7.6 2.5 10.7 3.3 14c.8 3.4 3.6 5.6 6.4 5.4.8 0 1.6-.3 2.3-.7.7.4 1.5.7 2.3.7 2.8.2 5.6-2 6.4-5.4.8-3.3-.5-6.4-3.4-7.7-1.7-.8-3.7-.7-5.3.2z"/><path class="ps-hw-ribs" d="M8.2 7.2c-1.4 3-1.4 7.5.6 11.6M15.8 7.2c1.4 3 1.4 7.5-.6 11.6"/><path class="ps-hw-stem" d="M12 6.5c0-1.6.6-2.8 2-3.6"/><g class="ps-hw-face"><path d="M7.4 11.6 9.6 10l.9 2.4z"/><path d="M16.6 11.6 14.4 10l-.9 2.4z"/><path d="M7 14.6c1.4 2.2 8.6 2.2 10 0-.9.5-1.6.6-2.2.6l-.5-.9-.7 1.1c-.8.1-1.4.1-2.2 0l-.7-1.1-.5.9c-.7 0-1.3-.1-2.2-.6z"/></g></svg></template></h1></a>
                </div>
                <a x-show="server" :href="boot.list_url" class="ps-btn ps-back-overview">
                    <svg aria-hidden="true"><use href="#ps-back"/></svg><span>All servers</span>
                </a>
            </div>
            <nav class="ps-top-actions" aria-label="Panel navigation" :class="{'nav-open': navMenu}"
                 x-on:click.outside="navMenu=false; accountMenu=false"
                 x-on:keydown.escape.stop="navMenu=false; accountMenu=false">
                <button type="button" class="ps-btn is-icon is-subtle ps-mobile-menu" aria-label="Panel navigation" aria-controls="ps-navigation-items" :aria-expanded="navMenu"
                        x-on:click="navMenu=!navMenu; accountMenu=false; appearanceMenu=false; groupsMenu=false; notifyMenu=false">
                    <svg aria-hidden="true"><use href="#ps-menu"/></svg>
                </button>
                <div class="ps-nav-items" id="ps-navigation-items">
                    @if(\Simplify\Panel\Services\Extensions::web()) @include('server-directory::simplify.navigation') @endif
                    <a x-show="boot.admin_url" :href="server?.admin_server_url || boot.admin_url" class="ps-btn is-icon is-subtle" data-tip="Legacy panel" aria-label="Legacy panel">
                        <svg aria-hidden="true"><use href="#ps-legacy"/></svg><span class="ps-mobile-label">Legacy panel</span>
                    </a>
                    <button type="button" x-show="boot.settings_url" x-on:click="openPanelSettings()" class="ps-btn is-icon is-subtle" data-tip="Simplify settings" aria-label="Simplify settings" aria-haspopup="dialog">
                        <span class="ps-settings-mark" aria-hidden="true"><svg><use href="#ps-simplify"/></svg><svg class="ps-settings-gear"><use href="#ps-gear"/></svg></span><span class="ps-mobile-label">Simplify settings</span>
                    </button>
                    <button type="button" x-show="installable && !embedded" x-cloak x-on:click="installApp()" class="ps-btn is-icon is-subtle" data-tip="Install app" aria-label="Install app">
                        <svg aria-hidden="true"><use href="#ps-download"/></svg><span class="ps-mobile-label">Install app</span>
                    </button>

                    {{-- Admin tools: Pelican admin pages Simplify does not replace, opened in a popup (admins only). --}}
                    <div class="ps-notify" x-show="adminPages().length && !(hostMode && !server)" x-on:click.outside="adminMenu=false" x-on:keydown.escape.stop="adminMenu=false; $refs.adminButton.focus()">
                        <button type="button" x-ref="adminButton" class="ps-btn is-icon is-subtle" data-tip="Admin tools" aria-label="Admin tools" aria-controls="ps-admin-menu" :aria-expanded="adminMenu"
                                x-on:click="adminMenu=!adminMenu; notifyMenu=false; appearanceMenu=false; groupsMenu=false; accountMenu=false">
                            <svg aria-hidden="true"><use href="#ps-shield"/></svg><span class="ps-mobile-label">Admin tools</span>
                        </button>
                        <div id="ps-admin-menu" class="ps-dropdown is-end ps-admin-menu" x-show="adminMenu" x-cloak x-transition.opacity>
                            <strong class="ps-dropdown-title">Admin tools</strong>
                            {{-- Same sections as host mode: coloured cards, Health with its checks and Legacy at the bottom. --}}
                            <div class="ps-admin-groups">
                                <template x-for="section in hostSections().filter((x) => !['health', 'legacy'].includes(x.key))" :key="section.key">
                                    <div class="ps-admin-group" :style="{'--ps-tone': section.color}">
                                        <span class="ps-admin-group-head"><span class="ps-host-rail-icon"><svg aria-hidden="true"><use :href="'#ps-'+section.icon"/></svg></span><span x-text="section.label"></span></span>
                                        <template x-for="item in section.pages" :key="item.key">
                                            <button type="button" class="ps-admin-item" x-on:click="openAdminPage(item)">
                                                <svg aria-hidden="true"><use :href="'#ps-'+item.icon"/></svg><span x-text="item.label"></span>
                                            </button>
                                        </template>
                                    </div>
                                </template>
                            </div>
                            <template x-if="adminHealthPage()">
                                <div class="ps-admin-health">
                                    <button type="button" class="ps-admin-health-title" x-on:click="openAdminPage(adminHealthPage())"><svg aria-hidden="true"><use href="#ps-heart"/></svg><span>Host health checks</span></button>
                                    <div class="ps-health-grid">
                                        @include('pelican-simplify::health-checks', ['open' => 'openAdminPage(adminHealthPage())'])
                                    </div>
                                </div>
                            </template>
                            {{-- Explain the panel's own log (root admins with an AI key in Simplify settings). --}}
                            <button type="button" class="ps-admin-health-title ps-admin-explain" x-show="explainSources().includes('panel')" x-on:click="adminMenu=false; explainError('panel')"><svg aria-hidden="true"><use href="#ps-question"/></svg><span>Explain panel errors</span></button>
                            <template x-for="section in hostSections().filter((x) => x.key === 'legacy')" :key="section.key">
                                <div class="ps-admin-legacy">
                                    <span class="ps-label">Legacy</span>
                                    <template x-for="item in section.pages" :key="item.key">
                                        <button type="button" class="ps-btn is-sm is-subtle" x-on:click="openAdminPage(item)" x-text="item.label"></button>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </div>

                    {{-- Notifications: alerts, pending changes and plugin updates in one dropdown. --}}
                    <div class="ps-notify" x-on:click.outside="notifyMenu=false" x-on:keydown.escape.stop="notifyMenu=false; $refs.notifyButton.focus()">
            {{-- A new notification drops down from the bell and slides back up after a few seconds. --}}
            <div class="ps-incoming" x-show="incomingShown" x-cloak role="status" aria-live="polite"
                 x-transition:enter="ps-incoming-move" x-transition:enter-start="is-up" x-transition:leave="ps-incoming-move" x-transition:leave-end="is-up"
                 x-on:mouseenter="clearTimeout(incomingTimer)" x-on:mouseleave="holdIncomingNotice(2500)">
                <template x-if="incomingNotice">
                    <div class="ps-notify-item" :class="'is-'+(incomingNotice.tone || 'info')">
                        <svg aria-hidden="true"><use :href="'#ps-'+(incomingNotice.tone==='ok'?'check':(incomingNotice.tone||'info')==='info'?'info':'alert')"/></svg>
                        <strong x-text="incomingNotice.title"></strong>
                        <small x-text="incomingNotice.text" x-show="incomingNotice.text"></small>
                        <span class="ps-notify-actions">
                            <template x-if="incomingNotice.action">
                                <a class="ps-btn is-sm" :href="incomingNotice.action.url" x-on:click="followNotice($event, {...incomingNotice, pelican: true})" x-text="incomingNotice.action.label"></a>
                            </template>
                            <button type="button" class="ps-btn is-sm is-subtle" x-on:click="hideIncomingNotice()">Dismiss</button>
                        </span>
                    </div>
                </template>
            </div>
                        <button type="button" x-ref="notifyButton" class="ps-btn is-icon is-subtle" data-tip="Notifications" aria-label="Notifications" aria-controls="ps-notify-menu" :aria-expanded="notifyMenu"
                                x-on:click="toggleNotifications()">
                            <svg aria-hidden="true"><use href="#ps-bell"/></svg><span class="ps-mobile-label">Notifications</span>
                            <span class="ps-notify-count" x-show="unreadNotifications()" x-text="unreadNotifications()"></span>
                        </button>
                        <div id="ps-notify-menu" class="ps-dropdown is-end ps-notify-menu" x-show="notifyMenu" x-cloak x-transition.opacity>
                            <div class="ps-notify-head">
                                <strong class="ps-dropdown-title">Notifications</strong>
                                <button type="button" class="ps-btn is-sm is-subtle" x-show="unreadNotifications()" x-on:click="markAllNotificationsRead()">Mark all read</button>
                                <button type="button" class="ps-btn is-sm is-subtle" x-show="canClearRead()" x-on:click="clearReadNotifications()">Clear read</button>
                                <button type="button" class="ps-btn is-sm is-icon is-subtle" data-tip="Show all" aria-label="Show all notifications" x-on:click="openAllNotifications()"><svg aria-hidden="true"><use href="#ps-expand"/></svg></button>
                            </div>
                            @include('pelican-simplify::notification-items')
                            <div class="ps-notify-list" x-show="pushOffer()">
                                <div class="ps-push-offer">
                                    <svg aria-hidden="true"><use href="#ps-bell"/></svg>
                                    <span>Get announcements as notifications on this device.</span>
                                    <button type="button" class="ps-btn is-sm" x-on:click="openNotifications()">Turn on</button>
                                    <button type="button" class="ps-btn is-sm is-icon is-subtle" data-tip="Not now" aria-label="Not now" x-on:click="hidePushOffer()"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
                                </div>
                            </div>
                            <div class="ps-dropdown-section" x-show="noticeHistory.length">
                                <span class="ps-label">Recent messages</span>
                                <div class="ps-notify-list">
                                    <template x-for="entry in noticeHistory" :key="entry.id">
                                        <div class="ps-notify-item" :class="'is-'+entry.tone">
                                            <svg aria-hidden="true"><use href="#ps-info"/></svg>
                                            <strong x-text="entry.text"></strong>
                                            <small x-text="entry.time"></small>
                                        </div>
                                    </template>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Own server groups and server order, saved with the account; a server sits in one group at most. --}}
                    <div class="ps-overview-appearance ps-overview-groups" x-show="!server && !hostMode && overviewPreferences.showGroupsButton" x-on:click.outside="groupsMenu=false" x-on:keydown.escape.stop="groupsMenu=false; $refs.overviewGroupsButton.focus()">
                        <button type="button" x-ref="overviewGroupsButton" class="ps-btn is-icon is-subtle" data-tip="Server groups" aria-label="Server groups" aria-controls="ps-overview-groups-menu" :aria-expanded="groupsMenu"
                                x-on:click="groupsMenu=!groupsMenu; appearanceMenu=false; accountMenu=false; notifyMenu=false">
                            <svg aria-hidden="true"><use href="#ps-files"/></svg><span class="ps-mobile-label">Server groups</span>
                        </button>
                        <div id="ps-overview-groups-menu" class="ps-dropdown is-end ps-overview-appearance-menu" x-show="groupsMenu" x-cloak x-transition.opacity>
                            <strong class="ps-dropdown-title">Server groups</strong>
                            <p class="ps-dropdown-hint">Saved with your account, so every device shows the same groups and order.</p>
                            <div class="ps-customize">
                                <div class="ps-customize-row">
                                    <div><strong>Server order</strong><small>For the overview and for groups that follow it</small></div>
                                    <div class="ps-segmented" role="group" aria-label="Server order">
                                        <template x-for="order in SERVER_ORDERS" :key="order.key">
                                            <button type="button" :aria-pressed="overviewServerOrder===order.key" x-on:click="setServerOrder(order.key)" x-text="order.label"></button>
                                        </template>
                                    </div>
                                </div>
                                <span class="ps-customize-head">My groups</span>
                                <small class="ps-group-note" x-show="!overviewGroups.length">Make your own groups, such as Survival or Friends, and pick which servers go in each. They are shown at the top of the overview.</small>
                                <template x-for="(group, index) in overviewGroups" :key="group.id">
                                    <div class="ps-group-edit" :class="{'is-open': groupEditing===group.id}">
                                        <div class="ps-group-row">
                                            <button type="button" class="ps-btn is-sm is-icon is-subtle ps-group-toggle" x-on:click="groupEditing = groupEditing===group.id ? null : group.id" :aria-expanded="groupEditing===group.id" :data-tip="groupEditing===group.id ? 'Done' : 'Servers and order'" :aria-label="'Servers and order for '+group.name"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                                            <span class="ps-group-dot" x-show="group.color" :style="{'background-color': group.color}" aria-hidden="true"></span>
                                            <input type="text" class="ps-input ps-group-name" :value="group.name" maxlength="40" aria-label="Group name" x-on:keydown.enter.prevent="$el.blur()" x-on:change="$el.value = renameOverviewGroup(group.id, $el.value)">
                                            <small class="ps-group-count" x-text="groupCount(group)+(groupCount(group)===1 ? ' server' : ' servers')"></small>
                                            <button type="button" class="ps-btn is-sm is-icon is-subtle ps-group-up" :disabled="index===0" x-on:click="moveOverviewGroup(group.id, -1)" data-tip="Move up" :aria-label="'Move '+group.name+' up'"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                                            <button type="button" class="ps-btn is-sm is-icon is-subtle ps-group-down" :disabled="index===overviewGroups.length-1" x-on:click="moveOverviewGroup(group.id, 1)" data-tip="Move down" :aria-label="'Move '+group.name+' down'"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                                            <button type="button" class="ps-btn is-sm is-icon is-subtle" x-on:click="removeOverviewGroup(group.id)" data-tip="Remove group" :aria-label="'Remove '+group.name"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
                                        </div>
                                        <div class="ps-group-servers" x-show="groupEditing===group.id">
                                            <div class="ps-group-order ps-group-color"><span>Group color</span>
                                                <span class="ps-group-color-choice">
                                                    <label class="ps-swatch ps-group-swatch" :class="{'is-empty': !group.color}" :style="group.color ? {'background-color': group.color} : {}" :data-tip="group.color ? 'Change group color' : 'Pick a group color'"><input type="color" class="ps-color-input" :value="group.color || '#878787'" x-on:change="setGroupColor(group.id, $el.value)" :aria-label="'Color for '+group.name"></label>
                                                    <button type="button" class="ps-btn is-sm is-subtle" x-show="group.color" x-on:click="setGroupColor(group.id, null)">Remove color</button>
                                                    <small x-show="!group.color">Off: every server keeps its own color</small>
                                                </span>
                                            </div>
                                            <label class="ps-group-order"><span>Order in this group</span>
                                                <select class="ps-input" :value="group.sort" x-on:change="setGroupOrder(group.id, $el.value)">
                                                    <template x-for="order in GROUP_ORDERS" :key="order.key"><option :value="order.key" x-text="order.label" :selected="group.sort===order.key"></option></template>
                                                </select>
                                            </label>
                                            <template x-for="(s, position) in groupServerList(group)" :key="s.uuid">
                                                <div class="ps-group-server" :class="{'is-member': group.servers.includes(s.uuid)}">
                                                    <button type="button" class="ps-customize-switch" role="switch" :aria-checked="group.servers.includes(s.uuid)" x-on:click="toggleGroupServer(group.id, s.uuid)">
                                                        <span><strong x-text="cardNames(s).large"></strong><small x-show="serverGroup(s.uuid) && serverGroup(s.uuid).id!==group.id" x-text="'Now in '+serverGroup(s.uuid)?.name"></small></span>
                                                        <span class="ps-switch" :class="{'is-on': group.servers.includes(s.uuid)}" aria-hidden="true"></span>
                                                    </button>
                                                    <span class="ps-group-server-move" x-show="group.sort==='manual' && group.servers.includes(s.uuid)">
                                                        <button type="button" class="ps-btn is-sm is-icon is-subtle ps-group-up" :disabled="position===0" x-on:click="moveGroupServer(group.id, s.uuid, -1)" data-tip="Move up" :aria-label="'Move '+cardNames(s).large+' up'"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                                                        <button type="button" class="ps-btn is-sm is-icon is-subtle ps-group-down" :disabled="position===groupCount(group)-1" x-on:click="moveGroupServer(group.id, s.uuid, 1)" data-tip="Move down" :aria-label="'Move '+cardNames(s).large+' down'"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                                                    </span>
                                                </div>
                                            </template>
                                            <small class="ps-group-note" x-show="!(boot.servers||[]).length">No servers yet.</small>
                                        </div>
                                    </div>
                                </template>
                                <button type="button" class="ps-btn is-sm ps-group-add" x-show="overviewGroups.length < 30" x-on:click="addOverviewGroup(); $nextTick(() => [...$el.parentElement.querySelectorAll('.ps-group-name')].pop()?.select())"><svg aria-hidden="true"><use href="#ps-plus"/></svg>New group</button>
                            </div>
                        </div>
                    </div>

                    {{-- Personal appearance preferences. --}}
                    <div class="ps-overview-appearance" x-show="!hostMode" x-on:click.outside="appearanceMenu=false" x-on:keydown.escape.stop="appearanceMenu=false; $refs.overviewAppearance.focus()">
                        <button type="button" x-ref="overviewAppearance" class="ps-btn is-icon is-subtle" :data-tip="server ? 'Customize server page' : 'Customize overview'" :aria-label="server ? 'Customize server page' : 'Customize overview'" aria-controls="ps-overview-appearance-menu" :aria-expanded="appearanceMenu"
                                x-on:click="appearanceMenu=!appearanceMenu; groupsMenu=false; accountMenu=false; notifyMenu=false">
                            <svg aria-hidden="true"><use href="#ps-wand"/></svg><span class="ps-mobile-label" x-text="server ? 'Customize server page' : 'Customize overview'">Customize overview</span>
                        </button>
                        <div id="ps-overview-appearance-menu" class="ps-dropdown is-end ps-overview-appearance-menu" x-show="appearanceMenu" x-cloak x-transition.opacity>
                            <strong class="ps-dropdown-title" x-text="server ? 'Customize server page' : 'Customize overview'">Customize overview</strong>
                            <p class="ps-dropdown-hint">Only for you, on this device.</p>
                            {{-- Server pages: the same personal preferences, stored with the overview ones. --}}
                            <template x-if="server">
                                <div class="ps-customize">
                                    <button type="button" class="ps-customize-switch" role="switch" x-show="halloweenSeason() && boot.appearance?.seasonal !== false" :aria-checked="overviewPreferences.halloween" x-on:click="setOverviewPreference('halloween', !overviewPreferences.halloween)">
                                        <span><strong>Halloween theme</strong><small>A few small Halloween touches until 2 November</small></span>
                                        <span class="ps-switch" :class="{'is-on': overviewPreferences.halloween}" aria-hidden="true"></span>
                                    </button>
                                    <button type="button" class="ps-customize-switch" role="switch" :aria-checked="overviewPreferences.serverFullWidth" x-on:click="setOverviewPreference('serverFullWidth', !overviewPreferences.serverFullWidth)">
                                        <span><strong>Full screen width</strong><small>Use the whole width of the screen instead of a centred column for server pages</small></span>
                                        <span class="ps-switch" :class="{'is-on': overviewPreferences.serverFullWidth}" aria-hidden="true"></span>
                                    </button>
                                    <button type="button" class="ps-customize-switch" role="switch" x-show="!phone" :aria-checked="consoleFocus" x-on:click="setConsoleFocus(!consoleFocus)">
                                        <span><strong>Bigger console</strong><small>Open server pages with the large console, without the menu next to it</small></span>
                                        <span class="ps-switch" :class="{'is-on': consoleFocus}" aria-hidden="true"></span>
                                    </button>
                                    <button type="button" class="ps-customize-switch" role="switch" x-show="!phone" :aria-checked="consolePeek" x-on:click="setConsolePeek(!consolePeek)">
                                        <span><strong>Log in the mini console</strong><small>While a section like Files is open, show the last log lines above the command field</small></span>
                                        <span class="ps-switch" :class="{'is-on': consolePeek}" aria-hidden="true"></span>
                                    </button>
                                </div>
                            </template>
                            <template x-if="!server">
                                <div class="ps-customize">
                                    <button type="button" class="ps-customize-switch" role="switch" x-show="halloweenSeason() && boot.appearance?.seasonal !== false" :aria-checked="overviewPreferences.halloween" x-on:click="setOverviewPreference('halloween', !overviewPreferences.halloween)">
                                        <span><strong>Halloween theme</strong><small>A few small Halloween touches until 2 November</small></span>
                                        <span class="ps-switch" :class="{'is-on': overviewPreferences.halloween}" aria-hidden="true"></span>
                                    </button>
                                    <div class="ps-customize-row">
                                        <div><strong>Layout</strong><small>Cards, small cards or rows</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Layout">
                                            <template x-for="view in [{key:'grid',label:'Cards',icon:'grid'},{key:'compact',label:'Compact',icon:'grid-small'},{key:'list',label:'List',icon:'list'}]" :key="view.key">
                                                <button type="button" :aria-pressed="overviewView===view.key" x-on:click="setOverviewView(view.key)"><svg aria-hidden="true"><use :href="'#ps-'+view.icon"/></svg><span x-text="view.label"></span></button>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="ps-customize-row" x-show="overviewView!=='list' && !overviewCompact">
                                        <div><strong>Columns</strong><small>Most cards per row</small></div>
                                        <div class="ps-segmented ps-columns-choice" role="group" aria-label="Columns">
                                            <template x-for="count in ['auto','2','3','4','5','6']" :key="count">
                                                <button type="button" :aria-pressed="overviewPreferences.columns===count" x-on:click="setOverviewPreference('columns', count)" x-text="count==='auto' ? 'Auto' : count"></button>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="ps-customize-row" x-show="overviewView!=='list' && !overviewCompact">
                                        <div><strong>Card width</strong><small>Size of each card</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Card width">
                                            <template x-for="size in [{key:'narrow',label:'Narrow'},{key:'normal',label:'Normal'},{key:'wide',label:'Wide'}]" :key="size.key">
                                                <button type="button" :aria-pressed="overviewPreferences.cardWidth===size.key" x-on:click="setOverviewPreference('cardWidth', size.key)" x-text="size.label"></button>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="ps-customize-row">
                                        <div><strong>Card icon</strong><small>The big picture at the top of each card</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Card icon">
                                            <button type="button" :aria-pressed="overviewPreferences.largeIcon==='server'" x-on:click="setOverviewPreference('largeIcon','server')">Server</button>
                                            <button type="button" :aria-pressed="overviewPreferences.largeIcon==='egg'" x-on:click="setOverviewPreference('largeIcon','egg')">Game</button>
                                        </div>
                                    </div>
                                    <div class="ps-customize-row">
                                        <div><strong>Card title</strong><small>Show the alias you gave it, or the real server name</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Card title">
                                            <button type="button" :aria-pressed="overviewPreferences.largeName==='alias'" x-on:click="setOverviewPreference('largeName','alias')">Alias</button>
                                            <button type="button" :aria-pressed="overviewPreferences.largeName==='name'" x-on:click="setOverviewPreference('largeName','name')">Name</button>
                                        </div>
                                    </div>
                                    <div class="ps-customize-row">
                                        <div><strong>Group by node</strong><small>Auto groups servers per node once you have more than one; Always also shows a single node</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Group by node">
                                            <template x-for="mode in [{key:'auto',label:'Auto'},{key:'always',label:'Always'},{key:'off',label:'Off'}]" :key="mode.key">
                                                <button type="button" :aria-pressed="overviewPreferences.groupByNode===mode.key" x-on:click="setOverviewPreference('groupByNode', mode.key)" x-text="mode.label"></button>
                                            </template>
                                        </div>
                                    </div>
                                    <button type="button" class="ps-customize-switch" role="switch" :aria-checked="overviewPreferences.fullWidth" x-on:click="setOverviewPreference('fullWidth', !overviewPreferences.fullWidth)">
                                        <span><strong>Full screen width</strong><small>Use the whole width of the screen instead of a centred column for the overview</small></span>
                                        <span class="ps-switch" :class="{'is-on': overviewPreferences.fullWidth}" aria-hidden="true"></span>
                                    </button>
                                    <button type="button" class="ps-customize-switch" role="switch" :aria-checked="overviewPreferences.showGroupsButton" x-on:click="setOverviewPreference('showGroupsButton', !overviewPreferences.showGroupsButton)">
                                        <span><strong>Server groups button</strong><small>A button in the top bar to make your own groups and choose the order of your servers</small></span>
                                        <span class="ps-switch" :class="{'is-on': overviewPreferences.showGroupsButton}" aria-hidden="true"></span>
                                    </button>
                                    <span class="ps-customize-head">Show on each card</span>
                                    <template x-for="option in [{key:'showMotd',label:'Message of the day',hint:'The Minecraft MOTD under the server name'},{key:'showCpu',label:'CPU usage',hint:'A small live CPU graph'},{key:'showRam',label:'Memory usage',hint:'A small live RAM graph'}]" :key="option.key">
                                        <button type="button" class="ps-customize-switch" role="switch" :aria-checked="overviewPreferences[option.key]" x-on:click="setOverviewPreference(option.key, !overviewPreferences[option.key])">
                                            <span><strong x-text="option.label"></strong><small x-text="option.hint"></small></span>
                                            <span class="ps-switch" :class="{'is-on': overviewPreferences[option.key]}" aria-hidden="true"></span>
                                        </button>
                                    </template>
                                    <div class="ps-customize-row">
                                        <div><strong>Quick actions</strong><small>Start, stop and restart buttons on each card: always, or only when you point at it (on a touch screen they are always shown)</small></div>
                                        <div class="ps-segmented" role="group" aria-label="Quick actions">
                                            <template x-for="mode in [{key:'off',label:'Off'},{key:'on',label:'On'},{key:'hover',label:'Hover'}]" :key="mode.key">
                                                <button type="button" :aria-pressed="overviewPreferences.quickActions===mode.key" x-on:click="setOverviewPreference('quickActions', mode.key)" x-text="mode.label"></button>
                                            </template>
                                        </div>
                                    </div>
                                    {{-- Server colours are a panel setting; point administrators at it from here. Group colours live with each group. --}}
                                    <div class="ps-customize-row" x-show="boot.settings_url">
                                        <div><strong>Server colors</strong><small>One color for every server, or a color per server, for everyone on the panel. A color per group is under Server groups.</small></div>
                                        <button type="button" class="ps-btn is-sm" x-on:click="appearanceMenu=false; openPanelSettings('appearance')">Open settings</button>
                                    </div>
                                </div>
                            </template>
                        </div>
                    </div>

                    {{-- Account: avatar with inline profile and sign-out actions. --}}
                    <div class="ps-account" x-data="{ themeOpen: false, pluginMenu: false }" x-effect="accountMenu || (themeOpen = pluginMenu = false)" :class="{'account-open': accountMenu}" x-on:click.outside="accountMenu=false" x-on:keydown.escape.stop="accountMenu=false">
                        <button type="button" x-on:click="accountMenu=!accountMenu; appearanceMenu=false; groupsMenu=false; notifyMenu=false" class="ps-btn ps-account-button" aria-label="Profile options" aria-controls="ps-account-actions" :aria-expanded="accountMenu">
                            <span class="ps-account-avatar" x-data="{failed:false}">
                                <img x-show="boot.avatar && !failed" :src="boot.avatar" alt="" x-on:error="failed=true">
                                <svg x-show="!boot.avatar || failed" aria-hidden="true"><use href="#ps-account"/></svg>
                            </span>
                            <span class="ps-account-username" x-text="boot.user"></span>
                        </button>
                        <div id="ps-account-actions" class="ps-account-menu" :style="{'--ps-account-count': (adminPages().length && !server ? 5 : 4) + (pluginPages().length ? 1 : 0) + (themeOpen ? 2 : 0) - (themeForced ? 1 : 0)}" :inert="!accountMenu" :aria-hidden="!accountMenu">
                            <div class="ps-account-actions-inner">
                                <button type="button" class="ps-btn is-icon" x-on:click="openAccount()" data-tip="Profile settings" aria-label="Profile settings" aria-haspopup="dialog">
                                    <svg aria-hidden="true"><use href="#ps-account"/></svg>
                                </button>
                                <button type="button" class="ps-btn is-icon" x-on:click="openNotifications()" data-tip="Notifications on your devices" aria-label="Notifications on your devices" aria-haspopup="dialog">
                                    <svg aria-hidden="true"><use href="#ps-bell"/></svg>
                                </button>
                                {{-- Account-level pages other plugins add (such as Legal Pages), listed below the menu. --}}
                                <button type="button" class="ps-btn is-icon" x-show="pluginPages().length" x-on:click="pluginMenu=!pluginMenu; themeOpen=false" data-tip="Plugin pages" aria-label="Plugin pages" aria-controls="ps-plugin-pages" :aria-expanded="pluginMenu">
                                    <svg aria-hidden="true"><use href="#ps-plugins"/></svg>
                                </button>
                                {{-- Theme: the current choice; clicking it unfolds Light, Dark and System. --}}
                                <button type="button" class="ps-btn is-icon" x-show="!themeOpen && !themeForced" x-on:click="themeOpen=true" :data-tip="'Theme: '+(theme==='light' ? 'Light' : theme==='dark' ? 'Dark' : 'System')" aria-label="Choose theme" :aria-expanded="themeOpen">
                                    <svg aria-hidden="true"><use :href="theme==='light' ? '#ps-sun' : theme==='dark' ? '#ps-moon' : '#ps-monitor'"/></svg>
                                </button>
                                <template x-for="t in ['light','dark','system']" :key="t">
                                    <button type="button" class="ps-btn is-icon ps-theme-option" x-show="themeOpen" :aria-pressed="theme===t" x-on:click="setTheme(t); themeOpen=false" :data-tip="t==='light' ? 'Light' : t==='dark' ? 'Dark' : 'System'" :aria-label="t+' theme'">
                                        <svg aria-hidden="true"><use :href="t==='light' ? '#ps-sun' : t==='dark' ? '#ps-moon' : '#ps-monitor'"/></svg>
                                    </button>
                                </template>
                                <button type="button" class="ps-btn is-icon" x-show="adminPages().length && !server" x-on:click="setHostMode(!hostMode); accountMenu=false" :data-tip="hostMode ? 'Switch to simple mode' : 'Switch to host mode'" :aria-label="hostMode ? 'Switch to simple mode' : 'Switch to host mode'">
                                    <svg aria-hidden="true"><use :href="hostMode ? '#ps-grid' : '#ps-host'"/></svg>
                                </button>
                                <form method="post" action="{{ route('filament.app.auth.logout') }}">@csrf
                                    <button type="submit" class="ps-btn is-icon" data-tip="Sign out" aria-label="Sign out"><svg aria-hidden="true"><use href="#ps-logout"/></svg></button>
                                </form>
                            </div>
                        </div>
                        <div id="ps-plugin-pages" class="ps-dropdown is-end ps-plugin-pages" x-show="accountMenu && pluginMenu" x-cloak x-transition.opacity>
                            <strong class="ps-dropdown-title">Plugin pages</strong>
                            <div class="ps-notify-list">
                                <template x-for="page in pluginPages()" :key="page.key">
                                    <button type="button" class="ps-notify-item" style="--ps-tone: #2dd4bf" x-on:click="openPluginPage(page)">
                                        <svg aria-hidden="true"><use :href="page.new_tab ? '#ps-link' : '#ps-plugins'"/></svg><strong x-text="page.label"></strong><small x-text="'From '+page.plugin+(page.new_tab ? ' · opens in a new tab' : '')"></small>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        {{-- Host mode (admins, large hosts): server buttons per node, a colour-coded admin rail and the page. --}}
        <section class="ps-host" :class="{'has-server': !!hostServer}" x-show="!server && hostMode" x-cloak :style="accentStyle('overview')">
                <aside class="ps-host-servers" :class="{'is-open': hostServersOpen}" aria-label="Servers">
                    <button type="button" class="ps-btn is-sm ps-host-servers-toggle" x-on:click="hostServersOpen=!hostServersOpen" :aria-expanded="hostServersOpen"><svg aria-hidden="true"><use href="#ps-list"/></svg><span x-text="hostServer ? cardNames(hostServer).large : 'Servers ('+(boot.servers||[]).length+')'"></span><svg class="ps-host-switch-chevron" aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                    <div class="ps-host-server-list">
                        <template x-for="node in hostNodes()" :key="node.id">
                            <div class="ps-host-node">
                                <span class="ps-label"><svg aria-hidden="true"><use href="#ps-host"/></svg><span x-text="node.name"></span><small x-text="node.servers.length+(node.servers.length===1?' server':' servers')"></small></span>
                                <template x-for="s in node.servers" :key="s.uuid">
                                    <a class="ps-host-server" :href="s.linked ? s.url : null" :style="accentStyle(s.uuid)" :aria-disabled="!s.linked" :aria-current="hostServer?.uuid===s.uuid ? 'page' : null" x-on:click="if (s.linked && !$event.ctrlKey && !$event.metaKey && !$event.shiftKey) { $event.preventDefault(); openHostServer(s); }">
                                        <span class="ps-host-server-arrow" x-show="hostServer?.uuid===s.uuid" x-on:click.prevent.stop="closeHostServer()" role="button" aria-label="Close this server" data-tip="Close"><svg aria-hidden="true"><use href="#ps-arrow-right"/></svg></span>
                                        <span class="ps-host-server-top">
                                            <strong x-text="cardNames(s).large"></strong>
                                            <span class="ps-badge ps-status" :class="s.status"><i></i><span x-text="s.status"></span></span>
                                        </span>
                                        <span class="ps-host-server-meta">
                                            <span x-text="hostServerVersion(s)"></span>
                                            <span class="ps-host-players"><svg aria-hidden="true"><use href="#ps-players"/></svg><span x-text="playerCount(s)"></span></span>
                                        </span>
                                    </a>
                                </template>
                            </div>
                        </template>
                        <p class="ps-empty" x-show="!(boot.servers||[]).length">No servers yet.</p>
                    </div>
                </aside>
                <nav class="ps-host-rail" aria-label="Admin sections" x-init="scrollHint($el)">
                    <span class="ps-label ps-host-rail-title">Admin</span>
                    <div class="ps-host-rail-items">
                        <template x-for="section in hostSections().filter((x) => x.key !== 'health')" :key="section.key">
                            <button type="button" class="ps-host-rail-item" :style="{'--ps-tone': section.color}" :aria-current="hostSection?.key===section.key ? 'page' : null" x-on:click="openHostSection(section)" :aria-label="section.label">
                                <span class="ps-host-rail-icon"><svg aria-hidden="true"><use :href="'#ps-'+section.icon"/></svg></span><span class="ps-host-rail-label" x-text="section.label"></span>
                            </button>
                        </template>
                    </div>
                    <template x-for="section in hostSections().filter((x) => x.key === 'health')" :key="section.key">
                        <button type="button" class="ps-host-rail-item is-health" :style="{'--ps-tone': section.color}" :aria-current="hostSection?.key===section.key ? 'page' : null" x-on:click="openHostSection(section)" :aria-label="section.label">
                            <span class="ps-host-rail-icon"><svg aria-hidden="true"><use :href="'#ps-'+section.icon"/></svg></span><span class="ps-host-rail-label" x-text="section.label"></span>
                        </button>
                    </template>
                    <div class="ps-health-grid" x-show="healthChecks().length" role="group" aria-label="Current health checks">
                        @include('pelican-simplify::health-checks', ['open' => 'openHostSection(hostSections().find((x) => x.key === \'health\'))'])
                    </div>
                </nav>
                {{-- A server picked on the left opens here, over the admin pages; the cross or another server closes it. --}}
                <div class="ps-host-serverpane" x-show="hostServer" x-cloak :style="accentStyle(hostServer?.uuid || 'overview')">
                    <div class="ps-host-pane-actions">
                        <a class="ps-btn is-sm is-icon" :href="hostServer?.url" data-tip="Open full page" aria-label="Open full page"><svg aria-hidden="true"><use href="#ps-external"/></svg></a>
                        <button type="button" class="ps-btn is-sm is-icon" x-on:click="closeHostServer()" data-tip="Close" aria-label="Close server"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
                    </div>
                    <div class="ps-host-frame">
                        <template x-for="s in hostServer ? [hostServer] : []" :key="s.uuid">
                            <iframe :src="frameUrl(s.url)" :title="s.name"></iframe>
                        </template>
                    </div>
                </div>
                <div class="ps-host-main">
                    <header class="ps-host-head" x-show="hostSection">
                        <div class="ps-host-title"><span class="ps-host-rail-icon"><svg aria-hidden="true"><use :href="'#ps-'+(hostSection?.icon||'host')"/></svg></span>
                        <h2 x-text="hostSection?.label"></h2></div>
                        <div class="ps-segmented ps-host-subtabs" x-show="hostSection?.pages.length > 1" role="group" aria-label="Pages">
                            <template x-for="item in hostSection?.pages || []" :key="item.key">
                                <button type="button" :aria-pressed="hostPage?.key===item.key" x-on:click="setHostPage(item)"><svg aria-hidden="true"><use :href="'#ps-'+item.icon"/></svg><span x-text="item.label"></span></button>
                            </template>
                        </div>
                    </header>
                    <div class="ps-host-frame">
                        <template x-if="hostPage">
                            <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(hostPage.url)" :title="hostPage.label" x-on:load="styleFrame($el, 'native')"></iframe>
                        </template>
                    </div>
                </div>
        </section>

        {{-- Overview -------------------------------------------------------------------------------- --}}
        <section x-show="!server && !hostMode" class="ps-overview" :class="{'is-list': overviewView==='list'}" :style="{'--grid-columns': overviewColumns(), ...overviewGridStyle()}">
            <div class="ps-server-scroll" tabindex="0" role="region" aria-label="Servers">
                <div class="ps-server-stage" :class="{'is-list': overviewView==='list'}">
                    @include('pelican-simplify::announcement-bars')
                    <div class="ps-overview-toolbar" x-init="scrollHint($el)">
                        <div class="ps-create-tiles" x-show="boot.can_create">
                            {{-- The Server Maker: Minecraft and every other game in one creator. --}}
                            <button type="button" x-show="canCreateGame('server')" x-on:click="openCreate('server')" class="ps-create-card is-server" :style="creationAccent('server')" aria-label="Create server" aria-haspopup="dialog">
                                <span class="ps-create-plus"><svg aria-hidden="true"><use href="#ps-host"/></svg><span class="ps-create-add"><svg aria-hidden="true"><use href="#ps-plus"/></svg></span></span>
                                <h3><span>Create</span><strong>Server</strong></h3>
                            </button>
                            {{-- Game add-on off: administrators still reach other games through Pelican's own form. --}}
                            <button type="button" x-show="pelicanFormForOthers()" x-on:click="openCreate('other')" class="ps-create-card is-other" :style="creationAccent('other')" aria-label="Create other server with Pelican's form" aria-haspopup="dialog">
                                <span class="ps-create-plus"><svg aria-hidden="true"><use href="#ps-gamepad"/></svg><span class="ps-create-add"><svg aria-hidden="true"><use href="#ps-plus"/></svg></span></span>
                                <h3><span>Create</span><strong>Other</strong><span>server</span></h3>
                            </button>
                            {{-- Easy creator off: one tile for Pelican's native creation (administrators). --}}
                            <button type="button" x-show="canCreateGame('native')" x-on:click="openCreate('native')" class="ps-create-card is-native" :style="creationAccent('native')" aria-label="Create server with Pelican's creator" aria-haspopup="dialog">
                                <span class="ps-create-plus"><svg aria-hidden="true"><use href="#ps-host"/></svg><span class="ps-create-add"><svg aria-hidden="true"><use href="#ps-plus"/></svg></span></span>
                                <h3><span>Create</span><strong>New</strong><span>server</span></h3>
                            </button>
                        </div>
                        <div class="ps-game-filters" role="group" aria-label="Filter servers by game">
                            <button type="button" class="ps-chip" :aria-pressed="gameFilter==='all'" x-on:click="setGameFilter('all')">All</button>
                            <template x-for="game in gameOptions()" :key="game.key">
                                <button type="button" class="ps-chip" :aria-pressed="gameFilter===game.key" x-on:click="setGameFilter(game.key)" x-text="game.label"></button>
                            </template>
                        </div>
                        <div class="ps-node-filters" x-show="nodeOptions().length > 1" role="group" aria-label="Filter servers by node">
                            <input type="search" class="ps-input ps-node-search" x-show="nodeOptions().length > 3" x-model.debounce.200ms="nodeSearch" placeholder="Search nodes" aria-label="Search nodes">
                            <button type="button" class="ps-chip" :aria-pressed="nodeFilter==='all'" x-on:click="nodeFilter='all'"><svg aria-hidden="true"><use href="#ps-host"/></svg>All nodes</button>
                            <template x-for="node in nodeOptions().filter((n) => !nodeSearch || n.name.toLowerCase().includes(nodeSearch.toLowerCase()))" :key="node.id">
                                <button type="button" class="ps-chip" :aria-pressed="nodeFilter===node.id" x-on:click="nodeFilter=node.id" x-text="node.name"></button>
                            </template>
                        </div>
                        {{-- Administrators see everyone's servers; like Pelican's own list they can narrow it to their own (owner or subuser) or other people's. --}}
                        <div class="ps-owner-filters" x-show="ownerFilterShown()" role="group" aria-label="Filter servers by owner">
                            <template x-for="scope in [{ key: 'all', label: 'All servers' }, { key: 'mine', label: 'My servers' }, { key: 'others', label: 'Others' }]" :key="scope.key">
                                <button type="button" class="ps-chip" :aria-pressed="overviewPreferences.serverScope===scope.key" x-on:click="setOverviewPreference('serverScope', scope.key)"><svg x-show="scope.key==='all'" aria-hidden="true"><use href="#ps-account"/></svg><span x-text="scope.label"></span></button>
                            </template>
                        </div>
                    </div>
                    {{-- Buttons other plugins add to Pelican's server list (such as Create server from User Creatable Servers). --}}
                    <div class="ps-plugin-actions" x-show="pluginActions('app').length" role="group" aria-label="Buttons from other plugins">
                        <template x-for="action in pluginActions('app')" :key="action.key">
                            <button type="button" class="ps-btn" :disabled="action.disabled || pluginActionBusy===action.key" :aria-busy="pluginActionBusy===action.key" x-on:click="runPluginAction(action)" :data-tip="action.plugin ? 'From the '+action.plugin+' plugin' : 'From another plugin'">
                                <span class="ps-plugin-action-icon" x-show="action.icon" x-html="action.icon" aria-hidden="true"></span><span x-text="action.label"></span>
                            </button>
                        </template>
                    </div>
                    {{-- Widgets other plugins add to Pelican's server list (such as resource limits), sized to their content. --}}
                    <template x-if="boot.plugin_widgets_url">
                        <div class="ps-plugin-widgets" :class="{'is-empty': !pluginWidgetHeights.app}" :style="{'--ps-widgets-height': (pluginWidgetHeights.app || 0)+'px'}">
                            <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(boot.plugin_widgets_url)" title="Plugin widgets" x-on:load="pluginWidgetsLoaded($el, 'app')"></iframe>
                        </div>
                    </template>
                    <div class="ps-server-grid" :class="{'is-list': overviewView==='list', 'is-compact': overviewView==='compact', 'has-motd': overviewPreferences.showMotd, 'no-metrics': !overviewMetrics().length, 'no-quick-actions': quickActionsMode()==='off', 'quick-actions-on': quickActionsMode()==='on'}">
                        <template x-for="s in overviewItems()" :key="s.uuid">
                            <div class="ps-server-entry" :class="{'is-node-heading': !!s.isNodeHeader, 'has-card-motd': overviewPreferences.showMotd && s.game==='minecraft' && !!s.motd, 'has-power': quickActionsMode()!=='off' && s.linked && Object.values(s.permissions || {}).some(Boolean), 'power-shown': quickActionsMode()==='on', 'confirming-power': powerConfirmation?.uuid===s.uuid}" :style="accentStyle(s.uuid)">
                                <template x-if="s.isNodeHeader">
                                    <h2 class="ps-node-heading" :class="{'has-color': !!s.color}"><svg aria-hidden="true"><use :href="'#ps-'+(s.icon || 'host')"/></svg><span x-text="s.name"></span><small x-text="s.count+(s.count===1?' server':' servers')"></small></h2>
                                </template>
                                <template x-if="!s.isNodeHeader">
                                <article class="ps-server-card" :class="{'locked': !s.linked}">
                                    <span class="ps-offline-artwork" x-show="s.status==='offline'" aria-label="Server offline"><svg aria-hidden="true"><use href="#ps-offline"/></svg></span>
                                    <span class="ps-card-background ps-banner-color" :class="{'is-auto': s.background_id==='color'}" x-show="bannerColor(s) && s.status!=='offline'" :style="bannerColor(s)" aria-hidden="true"></span>
                                    <img class="ps-card-background" x-show="s.background && s.status!=='offline'" :src="safeImage(s.background)" alt="" loading="lazy" x-on:error="$el.style.visibility='hidden'">
                                    <button class="ps-server-open" x-on:click="s.linked && (location.href=s.url)" :disabled="!s.linked" :aria-label="s.linked ? 'Open '+s.name : s.name+' — not assigned to you'">
                                        <div class="ps-card-head">
                                            <span class="ps-card-icons" :class="{'egg-primary': overviewPreferences.largeIcon==='egg' && !!(s.egg_icon || s.software_icon)}">
                                                <span class="ps-card-icon">
                                                    <img x-show="s.server_icon || s.icon" :src="safeImage(s.server_icon || s.icon)" alt="Server icon" loading="lazy" x-on:load="$el.style.visibility=''" x-on:error="$el.style.visibility='hidden'">
                                                    <svg x-show="!s.server_icon && !s.icon" aria-hidden="true"><use href="#ps-cube"/></svg>
                                                </span>
                                                <span class="ps-card-egg-icon" x-show="s.egg_icon || s.software_icon" data-tip-label="Server software" :data-tip="softwareTooltip(s)" :aria-label="softwareTooltip(s)">
                                                    <img :src="safeImage(s.egg_icon || s.software_icon)" alt="" loading="lazy" x-on:load="$el.style.visibility=''" x-on:error="$el.style.visibility='hidden'">
                                                </span>
                                            </span>
                                        </div>
                                        <div class="ps-card-title">
                                            <div class="ps-card-title-row" x-data="{observer:null,width:0,init(){this.observer=new ResizeObserver(()=>{const w=this.$el.clientWidth;if(w!==this.width){this.width=w;this.fitCardTitle(this.$el,cardNames(s).large)}});this.observer.observe(this.$el)},destroy(){this.observer?.disconnect()}}"
                                                 x-effect="const name=cardNames(s).large; $nextTick(()=>fitCardTitle($el,name))">
                                                <h3 x-text="cardNames(s).large"></h3>
                                                <small class="ps-card-real-name" :class="{'no-alias': !cardNames(s).small}" x-text="cardNames(s).small ? '('+cardNames(s).small+')' : ' '"></small>
                                            </div>
                                            <div class="ps-card-motd ps-motd-preview ps-motd-display" x-show="overviewPreferences.showMotd && s.game==='minecraft' && s.motd" x-data="{observer:null,init(){this.observer=new ResizeObserver(()=>this.fitMotd(this.$el));this.observer.observe(this.$el)},destroy(){this.observer?.disconnect()}}" x-effect="s.motd; overviewPreferences.showMotd; $nextTick(()=>fitMotd($el))"><template x-for="(part,index) in motdPreview(s.motd)" :key="index"><span :style="part.style" x-text="part.text"></span></template></div>
                                        </div>
                                        <div class="ps-card-usage" x-show="overviewMetrics().length" :class="{'single-metric': overviewMetrics().length===1}">
                                            <template x-for="metric in overviewMetrics()" :key="metric.key">
                                                <div class="ps-card-mini-metric">
                                                    <span class="ps-card-usage-label">
                                                        <span class="ps-card-metric-name"><svg aria-hidden="true"><use :href="'#ps-'+metric.icon"/></svg><span x-text="metric.label"></span></span>
                                                        <strong x-text="metric.key==='cpu' ? cpuLabel(s) : cardRamLabel(s)"></strong>
                                                    </span>
                                                    <svg class="ps-card-graph" viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true">
                                                        <path class="ps-card-graph-axis" d="M2 27H98"/>
                                                        <path :d="cardGraph(s, metric.key)"/>
                                                        <circle x-show="cardGraphPoint(s, metric.key)!==null" cx="98" :cy="cardGraphPoint(s, metric.key) || 0" r="1.4"/>
                                                    </svg>
                                                </div>
                                            </template>
                                        </div>
                                        <div class="ps-card-badges ps-identity-badges">
                                            <span class="ps-badge is-strong ps-list-game"><svg aria-hidden="true"><use :href="s.game==='minecraft' ? '#ps-cube' : '#ps-gamepad'"/></svg><span x-text="s.game_label"></span></span>
                                            <span class="ps-badge ps-status" :class="s.status"><i></i><span x-text="s.status"></span></span>
                                        </div>
                                        <div class="ps-card-bottom" x-show="overviewView!=='list'">
                                            <span x-text="playerCount(s)"></span>
                                            <svg aria-hidden="true"><use :href="s.linked ? '#ps-chevron' : '#ps-lock'"/></svg>
                                        </div>
                                    </button>
                                    <div class="ps-card-footer" x-show="boot.web || overviewView==='list'">
                                        @if(\Simplify\Panel\Services\Extensions::web()) @include('server-directory::simplify.visibility') @endif
                                        <button type="button" class="ps-list-player-count" x-show="overviewView==='list'" x-on:click="s.linked && (location.href=s.url)" :disabled="!s.linked" :aria-label="s.linked ? 'Open '+s.name : s.name+' — not assigned to you'">
                                            <span x-text="playerCount(s)"></span>
                                            <svg aria-hidden="true"><use :href="s.linked ? '#ps-chevron' : '#ps-lock'"/></svg>
                                        </button>
                                    </div>
                                    <div class="ps-overview-power-wrap" x-show="quickActionsMode()!=='off'">
                                        <div class="ps-overview-power" :class="{'is-confirming': powerConfirmation?.uuid===s.uuid}" role="group" :aria-label="'Power controls for '+(s.alias || s.name)">
                                            <template x-for="action in [{key:'start',label:'Start',icon:'play'},{key:'stop',label:'Stop',icon:'stop'},{key:'restart',label:'Restart',icon:'restart'},{key:'kill',label:'Force stop',icon:'kill'}]" :key="action.key">
                                                <button type="button" class="ps-btn is-icon" :class="{'is-danger': action.key==='kill'}" :data-power="action.key" :data-tip="action.label" :aria-label="action.label+' '+(s.alias || s.name)" :disabled="!!overviewPowerBusy || !canOverviewPower(s, action.key)" x-on:click.stop="overviewPower(s, action.key)">
                                                    <svg aria-hidden="true"><use :href="'#ps-'+action.icon"/></svg>
                                                </button>
                                            </template>
                                            <div class="ps-power-confirm" x-show="powerConfirmation?.uuid===s.uuid" x-cloak>
                                                <button type="button" class="ps-btn is-icon" data-tip="Cancel" aria-label="Cancel power action" x-on:click.stop="powerConfirmation=null"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
                                                <button type="button" class="ps-btn is-icon is-primary" :data-tip="'Confirm '+powerActionLabel(powerConfirmation?.action)+(powerConfirmation?.action==='kill' ? ' — unsaved progress may be lost' : '')" :aria-label="'Confirm '+powerActionLabel(powerConfirmation?.action)" x-on:click.stop="overviewPower(s, powerConfirmation.action, true)"><svg aria-hidden="true"><use href="#ps-check"/></svg></button>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                                </template>
                            </div>
                        </template>
                    </div>
                    <p x-show="!boot.servers.length" class="ps-empty">No servers yet.</p>
                </div>
            </div>

            {{-- Host health dock. --}}
            <section class="ps-health-panel" :style="accentStyle('overview')" x-on:click.outside="healthExpanded=false; healthOpenNodes=[]" x-show="boot.features.host_health" :class="{'expanded': healthExpanded}">
                <article class="ps-host-health" role="button" tabindex="0" aria-label="View health by node" :aria-expanded="healthExpanded" aria-controls="ps-health-details"
                         x-on:click="openHostHealth()" x-on:keydown.enter.prevent="openHostHealth()" x-on:keydown.space.prevent="openHostHealth()">
                    <div class="ps-host-state">
                        <span class="ps-host-emblem ps-health-heart" :class="boot.host_health?.state || 'unavailable'" role="img" :aria-label="'Host health: '+(boot.host_health?.label || 'Unavailable')">
                            <svg class="ps-host-heart" aria-hidden="true"><use href="#ps-heart"/></svg>
                            <span class="ps-host-server-badge"><svg aria-hidden="true"><use href="#ps-host"/></svg></span>
                        </span>
                        <div>
                            <div class="ps-host-heading"><h3>Host health</h3><svg class="ps-health-expand" :class="{'expanded': healthExpanded}" aria-hidden="true"><use href="#ps-chevron"/></svg></div>
                            <span class="ps-health-status" :class="boot.host_health?.state || 'unavailable'"><strong x-text="boot.host_health?.label || 'Unavailable'"></strong></span>
                            <small x-text="(boot.host_health?.available ?? 0)+' / '+(boot.host_health?.hosts ?? 0)+' hosts reporting'"></small>
                            <small class="ps-health-phone-summary" x-text="'CPU '+hostValue('cpu')+' · RAM '+hostValue('memory')"></small>
                        </div>
                    </div>
                    <template x-for="metric in hostMetrics" :key="metric.key">
                        <div class="ps-host-metric">
                            <div class="ps-host-heading">
                                <svg aria-hidden="true"><use :href="'#ps-'+metric.icon"/></svg><span x-text="metric.label"></span>
                                <span class="ps-health-heart" :class="hostMetricState(metric.key)" role="img" :aria-label="metric.label+': '+hostMetricLabel(metric.key)" :data-tip="hostMetricLabel(metric.key)"><svg aria-hidden="true"><use href="#ps-heart"/></svg></span>
                            </div>
                            <strong :class="{'ps-network-value': metric.key==='network'}" x-text="metric.key==='network' ? hostRate() : hostValue(metric.key)"></strong>
                            <span class="ps-meter" x-show="metric.key!=='network'"><span :style="{width: hostFill(metric.key)+'%'}"></span></span>
                            <small x-show="metric.key==='network'" x-text="'Used '+hostValue('network')"></small>
                            <small x-show="metric.key==='cpu' && boot.host_health?.hosts>1">Average across reporting hosts</small>
                        </div>
                    </template>
                </article>
                <div id="ps-health-details" class="ps-health-drawer" :inert="!healthExpanded" :aria-hidden="!healthExpanded">
                    <div>
                        <div class="ps-health-detail-toolbar">Expand a node to view its servers</div>
                        <div class="ps-node-health-list">
                            <template x-for="node in healthNodes()" :key="node.id">
                                <article class="ps-node-health" :class="{'expanded': healthNodeOpen(node)}">
                                    <div class="ps-node-summary" x-on:click="if(!$event.target.closest('button')) toggleHealthNode(node)">
                                        <header>
                                            <button type="button" class="ps-node-toggle" :aria-expanded="healthNodeOpen(node)" :aria-controls="'ps-node-servers-'+node.id" x-on:click="toggleHealthNode(node)">
                                                <svg class="ps-node-symbol" aria-hidden="true"><use href="#ps-host"/></svg>
                                                <strong class="ps-node-name" x-text="node.name"></strong>
                                                <span class="ps-badge ps-status" :class="node.state" x-text="node.label"></span>
                                                <svg class="ps-node-arrow" :class="{'expanded': healthNodeOpen(node)}" aria-hidden="true"><use href="#ps-chevron"/></svg>
                                            </button>
                                        </header>
                                        <div class="ps-node-metrics">
                                            <template x-for="metric in hostMetrics" :key="metric.key">
                                                <div class="ps-host-metric">
                                                    <div class="ps-host-heading"><svg aria-hidden="true"><use :href="'#ps-'+metric.icon"/></svg><span x-text="metric.label"></span></div>
                                                    <strong :class="{'ps-network-value': metric.key==='network'}" x-text="metric.key==='network' ? hostRate(node) : hostValue(metric.key, node)"></strong>
                                                    <span class="ps-meter" x-show="metric.key!=='network'"><span :style="{width: hostFill(metric.key, node)+'%'}"></span></span>
                                                    <small x-show="metric.key==='network'" x-text="'Used '+hostValue('network', node)"></small>
                                                </div>
                                            </template>
                                        </div>
                                    </div>
                                    <div class="ps-node-server-drawer" :class="{'expanded': healthNodeOpen(node)}" :id="'ps-node-servers-'+node.id" :inert="!healthNodeOpen(node)" :aria-hidden="!healthNodeOpen(node)">
                                        <div>
                                            <div class="ps-node-servers">
                                                <template x-for="item in nodeServers(node)" :key="item.uuid">
                                                    <div class="ps-node-server">
                                                        <div>
                                                            <a x-show="item.linked" :href="item.url" x-text="item.alias || item.name"></a>
                                                            <strong x-show="!item.linked" x-text="item.alias || item.name"></strong>
                                                            <span class="ps-badge ps-status" :class="item.status" x-text="item.status"></span>
                                                        </div>
                                                        <span><small>CPU</small><strong x-text="cpuLabel(item)"></strong></span>
                                                        <span><small>RAM</small><strong x-text="memoryLabel(item)"></strong></span>
                                                        <span><small>Storage</small><strong x-text="item.usage?.disk_bytes==null ? '—' : trafficBytes(item.usage.disk_bytes)"></strong></span>
                                                        <span><small>Network</small><strong x-text="serverRate(item)"></strong><small x-text="'Used '+serverTraffic(item)"></small></span>
                                                    </div>
                                                </template>
                                                <p x-show="!nodeServers(node).length" class="ps-help">No visible servers on this node.</p>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </template>
                            <p x-show="!boot.host_health?.nodes?.length" class="ps-empty">No nodes reporting yet.</p>
                        </div>
                    </div>
                </div>
            </section>
        </section>

        {{-- Server dashboard ----------------------------------------------------------------------- --}}
        <section x-show="server" class="ps-server-dashboard" :class="{'is-installing': installView()}">
            {{-- Status bar: slides in once the server card scrolls out of view, so status and power stay in reach. --}}
            <div class="ps-statusbar" :class="{'is-visible': statusBarVisible && !!server}" :inert="!statusBarVisible" role="region" aria-label="Server status">
                <span class="ps-statusbar-name" x-text="server?.alias || server?.name"></span>
                <span class="ps-badge ps-status" :class="status"><i></i><span x-text="status"></span></span>
                <button type="button" class="ps-statusbar-item ps-statusbar-address" x-show="server?.address" x-on:click="copyText(server.address)" data-tip="Copy server address"><svg aria-hidden="true"><use href="#ps-link"/></svg><span x-text="server?.address"></span></button>
                <span class="ps-statusbar-item" data-tip="Players online"><svg aria-hidden="true"><use href="#ps-players"/></svg><span x-text="playerCount({ ...server, status })"></span></span>
                <div class="ps-statusbar-power" :inert="['installing','restoring_backup'].includes(serverSetup())">
                    <button type="button" class="ps-btn is-sm is-primary" x-on:click="power('start')" :disabled="busy || !server?.permissions['control.start'] || status==='running'" aria-label="Start server" data-tip="Start"><svg aria-hidden="true"><use href="#ps-play"/></svg></button>
                    <button type="button" class="ps-btn is-sm" x-on:click="power('restart')" :disabled="busy || !server?.permissions['control.restart']" aria-label="Restart server" data-tip="Restart"><svg aria-hidden="true"><use href="#ps-restart"/></svg></button>
                    <button type="button" class="ps-btn is-sm" x-on:click="power('stop')" :disabled="busy || !server?.permissions['control.stop'] || status==='offline'" aria-label="Stop server" data-tip="Stop"><svg aria-hidden="true"><use href="#ps-stop"/></svg></button>
                    <button type="button" class="ps-btn is-sm is-danger" x-on:click="power('kill')" :disabled="busy || !server?.permissions['control.stop'] || status==='offline'" aria-label="Force stop server" data-tip="Kill"><svg aria-hidden="true"><use href="#ps-kill"/></svg></button>
                </div>
            </div>
            @include('pelican-simplify::announcement-bars')
            <div class="ps-alert is-warn ps-pending" x-show="server?.pending" x-cloak>
                <svg aria-hidden="true"><use href="#ps-alert"/></svg>
                <div>
                    <strong x-text="server?.pending?.error ? 'Changes need attention' : server?.pending?.file_only ? 'File changes saved — restart to load them' : 'Stop or restart to apply changes'"></strong>
                    <small x-text="server?.pending?.error || (server?.pending?.restart_at ? 'Applying changes when the server stops. The console remains available.' : (server?.pending?.file_only ? 'Files are saved. Restart now or schedule a restart if the game needs to reload them.' : 'Your saved changes are staged until the server stops or restarts.'))"></small>
                </div>
                <div class="ps-pending-actions">
                    <button type="button" x-on:click="restartChanges(0)" :disabled="busy" class="ps-btn is-sm" aria-label="Apply changes and restart"><svg aria-hidden="true"><use href="#ps-restart"/></svg><span>Restart now</span></button>
                    <button type="button" x-on:click="open('restart')" :disabled="busy || !showWidget('restart')" class="ps-btn is-sm is-icon" data-tip="Schedule restart" aria-label="Schedule restart"><svg aria-hidden="true"><use href="#ps-clock"/></svg></button>
                    <button type="button" x-on:click="discard()" :disabled="busy" class="ps-btn is-sm is-icon is-subtle" :aria-label="server?.pending?.file_only ? 'Dismiss restart reminder' : 'Discard changes'" :data-tip="server?.pending?.file_only ? 'Dismiss reminder (saved files stay changed)' : 'Discard changes'"><svg aria-hidden="true"><use href="#ps-undo"/></svg></button>
                </div>
            </div>

            {{-- Shown once after an installation finished on this page: one clear next step. --}}
            {{-- The same banner asks for the Minecraft EULA when it is still needed, so Pelican's own popup never shows. --}}
            <div class="ps-ready" :class="{'is-eula': eulaNeeded && !installReady}" x-show="(installReady || eulaNeeded) && !installView() && !['running','starting'].includes(status)" x-cloak x-transition.opacity role="status">
                <span class="ps-ready-mark" aria-hidden="true"><svg><use :href="installReady ? '#ps-check' : '#ps-file'"/></svg></span>
                <div>
                    <strong x-text="installReady ? 'Your server is ready' : 'Accept the Minecraft EULA'"></strong>
                    <small x-show="!eulaNeeded" x-text="server?.minecraft ? 'You can now start your server. The first start takes a little longer while the world is created.' : 'You can now start your server.'"></small>
                    <small x-show="eulaNeeded">Minecraft needs this once before the server can run. <a href="https://www.minecraft.net/eula" target="_blank" rel="noopener noreferrer">Read the Minecraft EULA</a></small>
                </div>
                <button type="button" class="ps-btn ps-ready-resources" x-show="installReady && server?.can_resources && showWidget('performance')" x-on:click="open('performance')" :disabled="busy"><svg aria-hidden="true"><use href="#ps-cpu"/></svg><span>Change resources</span></button>
                <button type="button" class="ps-btn is-primary ps-ready-start" x-show="server?.permissions['control.start']" x-on:click="readyStart()" :disabled="busy"><svg aria-hidden="true"><use href="#ps-play"/></svg><span x-text="eulaNeeded ? 'Accept and start' : 'Start server'"></span></button>
                <button type="button" class="ps-btn is-icon is-subtle" x-on:click="installReady=false; eulaNeeded=false" aria-label="Dismiss" data-tip="Dismiss"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
            </div>

            <article class="ps-server-info" aria-label="Server information" x-init="watchServerInfo($el)">
                {{-- Artwork has its own clipping layer, so it stays inside the card while the ⋯ menu lets the card overflow. --}}
                <span class="ps-info-decor">
                <span class="ps-offline-artwork" x-show="status==='offline'" aria-label="Server offline"><svg aria-hidden="true"><use href="#ps-offline"/></svg></span>
                <span class="ps-server-banner ps-banner-color" :class="{'is-auto': server?.background_id==='color'}" x-show="bannerColor(server) && status!=='offline'" :style="bannerColor(server)" aria-hidden="true"></span>
                <img class="ps-server-banner" x-show="server?.background && status!=='offline'" :src="safeImage(server?.background)" alt="" x-on:error="$el.style.visibility='hidden'">
                </span>
                <span class="ps-info-icons">
                    <span class="ps-info-icon ps-custom-server-icon" x-show="server?.server_icon" data-tip="server-icon.png"><img :src="safeImage(server?.server_icon)" alt="Custom server icon" x-on:load="$el.style.visibility=''" x-on:error="$el.style.visibility='hidden'"></span>
                    <span class="ps-info-icon ps-software-icon" :class="{'is-badge': server?.server_icon}" data-tip-label="Server software" :data-tip="server?.pack?.modpack_name || server?.software || 'Server software'">
                        <img x-show="server?.software_icon" :src="safeImage(server?.software_icon)" alt="Server software icon" x-on:load="$el.style.visibility=''" x-on:error="$el.style.visibility='hidden'">
                        <svg x-show="!server?.software_icon" aria-hidden="true"><use :href="server?.minecraft ? '#ps-cube' : '#ps-gamepad'"/></svg>
                    </span>
                </span>
                <div class="ps-info-content">
                    <div class="ps-game-title">
                        <h2 x-text="server?.alias || server?.name"></h2>
                        <small class="ps-real-server-name" x-show="server?.alias" x-text="'('+server?.name+')'"></small>
                        <button type="button" class="ps-btn is-icon is-sm is-subtle ps-alias-button" x-show="server?.permissions['settings.rename']" x-on:click="openAlias()" data-tip="Change alias" aria-label="Change alias" aria-haspopup="dialog"><svg aria-hidden="true"><use href="#ps-edit"/></svg></button>
                    </div>
                    {{-- One line: status, software and version, modpack, address. --}}
                    <div class="ps-info-meta">
                        <span class="ps-badge ps-status" :class="status"><i></i><span x-text="status"></span></span>
                        <span class="ps-info-meta-item" data-tip-label="Server software" :data-tip="server?.software || 'Not reported'"><svg aria-hidden="true"><use :href="server?.minecraft ? '#ps-cube' : '#ps-gamepad'"/></svg><span x-text="softwareLabel()"></span></span>
                        {{-- The modpack links to its page; this replaced the separate modpack card under the console. --}}
                        <a class="ps-info-meta-item ps-info-modpack" x-show="server?.pack?.modpack_name && safeLink(server?.pack?.modpack_url) !== '#'" :href="safeLink(server?.pack?.modpack_url)" target="_blank" rel="noopener noreferrer" data-tip="Modpack info"><svg aria-hidden="true"><use href="#ps-packages"/></svg><span x-text="modpackLabel()"></span><svg class="ps-info-modpack-out" aria-hidden="true"><use href="#ps-external"/></svg></a>
                        <span class="ps-info-meta-item ps-info-modpack" x-show="server?.pack?.modpack_name && safeLink(server?.pack?.modpack_url) === '#'" data-tip="Modpack"><svg aria-hidden="true"><use href="#ps-packages"/></svg><span x-text="modpackLabel()"></span></span>
                        <button type="button" class="ps-address ps-info-address" x-on:click="copyText(server.address)" :disabled="!server?.address" data-tip="Copy server address">
                            <svg aria-hidden="true"><use href="#ps-link"/></svg><span x-text="server?.address || 'No address assigned'"></span><svg aria-hidden="true"><use href="#ps-copy"/></svg>
                        </button>
                    </div>
                </div>
                <div class="ps-motd-preview ps-motd-display ps-info-motd" x-show="server?.properties?.motd || server?.pack?.motd" x-data="{observer:null,init(){this.observer=new ResizeObserver(()=>this.fitMotd(this.$el));this.observer.observe(this.$el)},destroy(){this.observer?.disconnect()}}" x-effect="server?.properties?.motd; server?.pack?.motd; $nextTick(()=>fitMotd($el))" aria-label="Message of the day"><template x-for="(part,index) in motdPreview(server?.properties?.motd || server?.pack?.motd || '')" :key="index"><span :style="part.style" x-text="part.text"></span></template></div>
                {{-- Power: one button that follows the state (Start or Stop), Restart, and the rest under ⋯. --}}
                <div class="ps-info-power" :inert="['installing','restoring_backup'].includes(serverSetup())" :class="{'is-locked': ['installing','restoring_backup'].includes(serverSetup())}" x-on:click.outside="colorMenu=false; infoMenu=false" x-on:keydown.escape.stop="colorMenu=false; infoMenu=false">
                    <button type="button" class="ps-btn ps-power-main" :class="{'is-primary': mainPower().action==='start'}" x-on:click="power(mainPower().action)" :disabled="busy || !server?.permissions['control.'+mainPower().action] || ['starting','stopping'].includes(status)" :aria-label="mainPower().label+' server'"><svg aria-hidden="true"><use :href="'#ps-'+mainPower().icon"/></svg><span x-text="mainPower().label"></span></button>
                    <button type="button" class="ps-btn ps-power-restart" x-on:click="power('restart')" :disabled="busy || !server?.permissions['control.restart'] || status!=='running'" aria-label="Restart server"><svg aria-hidden="true"><use href="#ps-restart"/></svg><span>Restart</span></button>
                    <button type="button" class="ps-btn is-icon ps-info-more-button" x-ref="infoMore" aria-label="More server options" aria-controls="ps-info-menu" :aria-expanded="infoMenu" x-on:click="infoMenu=!infoMenu; colorMenu=false"><svg aria-hidden="true"><use href="#ps-dots"/></svg></button>
                    <div id="ps-info-menu" class="ps-dropdown is-end ps-info-menu" x-show="infoMenu" x-cloak x-transition.opacity role="menu">
                        <button type="button" class="ps-menu-item" role="menuitem" :disabled="busy || !server?.permissions['settings.rename']" x-on:click="infoMenu=false; toggleColorMenu($refs.infoMore)"><span class="ps-color-dot" aria-hidden="true"></span><span>Server color</span></button>
                        <button type="button" class="ps-menu-item" role="menuitem" :disabled="busy || !server?.permissions['settings.rename']" x-on:click="infoMenu=false; openBackground()"><svg aria-hidden="true"><use href="#ps-image"/></svg><span>Server background</span></button>
                        <button type="button" class="ps-menu-item" role="menuitem" x-show="server?.permissions['settings.rename']" x-on:click="infoMenu=false; openAlias()"><svg aria-hidden="true"><use href="#ps-edit"/></svg><span>Change alias</span></button>
                        <button type="button" class="ps-menu-item ps-web-listing" role="menuitemcheckbox" x-show="server?.website_listing" x-cloak :aria-checked="!!server?.website_listing?.visible" :disabled="busy" x-on:click="saveListing(!server.website_listing.visible)"><svg aria-hidden="true"><use href="#ps-web"/></svg><span>Show on the website</span><span class="ps-switch" :class="{'is-on': server?.website_listing?.visible}" aria-hidden="true"></span></button>
                        <hr>
                        <button type="button" class="ps-menu-item is-danger" role="menuitem" :disabled="busy || !server?.permissions['control.stop'] || status==='offline'" x-on:click="infoMenu=false; power('kill')"><svg aria-hidden="true"><use href="#ps-kill"/></svg><span>Force stop</span></button>
                    </div>
                    <div class="ps-dropdown is-fixed ps-color-dropdown" x-show="colorMenu" x-cloak :style="colorMenuStyle" x-on:click.stop>
                        <span class="ps-label">Server color</span>
                        <small class="ps-color-group-note" x-show="serverGroup(server?.uuid)?.color" x-text="'You see the color of your group '+serverGroup(server?.uuid)?.name+'. This color is what everyone else sees.'"></small>
                        <div class="ps-swatches ps-color-presets">
                            <template x-for="(name,color) in (boot.available_colors || {})" :key="color">
                                <button type="button" class="ps-swatch" :style="{'background-color': color}" :data-tip="name" :aria-label="'Select '+name+' server color'" :aria-pressed="colorDraft===color" :disabled="busy" x-on:click="colorDraft=color"></button>
                            </template>
                        </div>
                        <label class="ps-check ps-custom-color"><span>Custom color</span><input type="color" class="ps-color-input" x-model="colorDraft" :disabled="busy" aria-label="Choose custom server color"></label>
                        <div class="ps-dropdown-actions">
                            <button type="button" class="ps-btn is-sm" x-on:click="colorMenu=false" :disabled="busy">Cancel</button>
                            <button type="button" class="ps-btn is-sm is-primary" x-on:click="commitServerColor()" :disabled="busy">Save</button>
                        </div>
                    </div>
                </div>
            </article>

            {{-- Live numbers in one row: players and the resource metrics. --}}
            <section class="ps-server-stats" aria-label="Server status">
                <article class="ps-card ps-stat ps-players-stat" x-show="server?.minecraft">
                    <div class="ps-stat-top"><span>Players</span><svg aria-hidden="true"><use href="#ps-players"/></svg></div>
                    <strong><span x-text="server?.players ?? '—'"></span><span class="ps-stat-total" x-text="server?.max_players ? ' / '+server.max_players : ''"></span></strong>
                    <ul class="ps-online-players" aria-label="Online players" x-show="server?.player_names?.length">
                        <template x-for="p in (server?.player_names || []).slice(0, 6)" :key="p.name"><li :data-tip="p.name"><img :src="head(p)" :alt="p.name" loading="lazy" x-on:error="$el.style.visibility='hidden'"></li></template>
                        <li class="ps-online-more" x-show="(server?.players || 0) > Math.min(6, server?.player_names?.length || 0)" x-text="'+'+((server?.players || 0) - Math.min(6, server?.player_names?.length || 0))"></li>
                    </ul>
                    <small class="ps-player-empty" x-show="!server?.player_names?.length" x-text="server?.players>0 ? 'Names not available' : 'No players online'"></small>
                </article>
                <template x-for="metric in metrics" :key="metric.key">
                    <article class="ps-card ps-stat">
                        <div class="ps-stat-top"><span x-text="metric.label"></span><svg aria-hidden="true"><use :href="'#ps-'+metric.icon"/></svg></div>
                        <strong x-text="metricValue(metric.key)"></strong>
                        <small x-text="metricLimit(metric.key)"></small>
                        <svg class="ps-spark" viewBox="0 0 200 36" preserveAspectRatio="none" aria-hidden="true"><path :d="spark(metric.key)"/></svg>
                    </article>
                </template>
            </section>

            {{-- Widgets other plugins add above Pelican's console (such as Player Counter), sized to their content. --}}
            <template x-if="server?.plugin_widgets_url">
                <div class="ps-plugin-widgets" :class="{'is-empty': !pluginWidgetHeights[server.uuid]}" :style="{'--ps-widgets-height': (pluginWidgetHeights[server.uuid] || 0)+'px'}">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(server.plugin_widgets_url)" title="Plugin widgets" x-on:load="pluginWidgetsLoaded($el, server.uuid)"></iframe>
                </div>
            </template>

            {{-- A new or reinstalled server: only the steps and the installation log until Pelican has finished. --}}
            <section class="ps-install" x-show="installView()" x-cloak role="status" aria-live="polite" :class="'is-'+serverSetup()" aria-label="Installation progress">
                <div class="ps-install-head">
                    <span class="ps-install-icon" aria-hidden="true">
                        <img x-show="server?.software_icon" :src="safeImage(server?.software_icon)" alt="" x-on:error="$el.style.visibility='hidden'">
                        <svg x-show="!server?.software_icon" aria-hidden="true"><use :href="server?.minecraft ? '#ps-cube' : '#ps-gamepad'"/></svg>
                    </span>
                    <div class="ps-install-title">
                        <h2 x-text="installTitle()"></h2>
                        <p x-text="installText()"></p>
                    </div>
                    <span class="ps-install-time" x-show="!installFailed() && installElapsed()"><strong x-text="installElapsed()"></strong><small x-show="installTypical()" x-text="installTypical()"></small></span>
                    <div class="ps-install-actions" x-on:click.outside="installMenu=false" x-on:keydown.escape.stop="installMenu=false">
                        <button type="button" class="ps-btn" x-show="serverSetup()==='installing'" :class="{'is-on': installNotify}" :aria-pressed="installNotify" x-on:click="toggleInstallNotify()"><svg aria-hidden="true"><use :href="installNotify ? '#ps-check' : '#ps-bell'"/></svg><span x-show="!installNotify">Notify me<span class="ps-install-long"> when ready</span></span><span x-show="installNotify">You get a notification</span></button>
                        <button type="button" class="ps-btn is-danger ps-install-kill" x-show="canKillInstall()" x-on:click="killInstall()" :disabled="busy"><svg aria-hidden="true"><use href="#ps-kill"/></svg><span>Kill</span></button>
                        <button type="button" class="ps-btn" x-show="installFailed() && !installKilled() && canExplain()" x-on:click="explainError('console')" :disabled="!!explain?.loading"><svg aria-hidden="true"><use href="#ps-question"/></svg><span>Explain<span class="ps-install-long"> this error</span></span></button>
                        <button type="button" class="ps-btn ps-install-resources" x-show="installFailed() && server?.can_resources && showWidget('performance')" x-on:click="open('performance')" :disabled="busy"><svg aria-hidden="true"><use href="#ps-cpu"/></svg><span>Change resources</span></button>
                        <button type="button" class="ps-btn is-primary" x-show="installFailed() && server?.permissions['settings.reinstall']" x-on:click="reinstall()" :disabled="busy"><svg aria-hidden="true"><use href="#ps-restart"/></svg><span>Try again</span></button>
                        <button type="button" class="ps-btn is-icon" x-show="serverSetup()!=='restoring_backup'" aria-label="More options" aria-controls="ps-install-menu" :aria-expanded="installMenu" x-on:click="installMenu=!installMenu"><svg aria-hidden="true"><use href="#ps-dots"/></svg></button>
                        <div id="ps-install-menu" class="ps-dropdown is-end ps-install-menu" x-show="installMenu" x-cloak x-transition.opacity role="menu">
                            <button type="button" class="ps-menu-item" role="menuitem" x-show="server?.files_url" x-on:click="installMenu=false; installFiles()"><svg aria-hidden="true"><use href="#ps-files"/></svg><span>Browse files</span></button>
                            <button type="button" class="ps-menu-item" role="menuitem" x-show="installFailed() && server?.permissions['startup.read']" x-on:click="installMenu=false; installStartup()"><svg aria-hidden="true"><use href="#ps-settings"/></svg><span>Startup settings</span></button>
                            <button type="button" class="ps-menu-item" role="menuitem" x-on:click="installMenu=false; copyText(installLogText(), 'Log copied')"><svg aria-hidden="true"><use href="#ps-copy"/></svg><span>Copy the log</span></button>
                            <hr x-show="server?.owner">
                            <button type="button" class="ps-menu-item is-danger" role="menuitem" x-show="server?.owner" x-on:click="installMenu=false; cancelInstall()"><svg aria-hidden="true"><use href="#ps-kill"/></svg><span x-text="installFailed() ? 'Delete server' : 'Cancel and delete server'"></span></button>
                        </div>
                    </div>
                </div>
                <ol class="ps-install-steps" x-show="serverSetup()!=='restoring_backup'">
                    <template x-for="(step, index) in installSteps()" :key="step.key">
                        <li class="ps-install-step" :class="'is-'+step.state" :aria-current="step.state==='active' ? 'step' : null">
                            <span class="ps-install-mark" aria-hidden="true">
                                <svg x-show="step.state==='done'"><use href="#ps-check"/></svg>
                                <svg x-show="step.state==='failed'"><use href="#ps-close"/></svg>
                                <i x-show="step.state==='active'"></i>
                                <b x-show="step.state==='todo'" x-text="index+1"></b>
                            </span>
                            <span class="ps-install-step-text"><strong x-text="step.label"></strong><small x-text="step.detail"></small></span>
                        </li>
                    </template>
                </ol>
            </section>

            <div class="ps-server-workspace" :class="{'has-dock': docked(), 'is-peek': consolePeek, 'is-focus': consoleFocus && !docked()}" x-init="fitWorkspace($el)" x-effect="docked(); consolePeek; consoleFocus; refitWorkspace()">
                {{-- A workspace opens in this block; the console then shrinks to a read-only view at the bottom right. --}}
                <div class="ps-dock" x-effect="syncDock($el, docked())"></div>
                <div class="ps-settings-column" :inert="['installing','restoring_backup'].includes(serverSetup())" :class="{'is-locked': ['installing','restoring_backup'].includes(serverSetup())}">
                    <nav class="ps-widget-grid" aria-label="Server sections" x-init="scrollHint($el)">
                        <button type="button" class="ps-widget is-console" style="--ps-tone: #9a9aa6" :aria-current="docked() ? null : 'page'" x-on:click="docked() && close()" aria-label="Live console">
                            <span class="ps-widget-icon" aria-hidden="true">›_</span>
                            <span><strong>Console</strong></span>
                        </button>
                        <template x-for="widget in widgets" :key="widget.key">
                            <button type="button" class="ps-widget" :style="{'--ps-tone': widgetTone(widget.key)}" :aria-current="modal===widget.key ? 'page' : null" :aria-label="widgetTitle(widget)+' — '+widgetDescription(widget)" x-show="showWidget(widget.key)" x-on:click="modal===widget.key ? null : open(widget.key)">
                                <span class="ps-widget-icon"><svg aria-hidden="true"><use :href="'#ps-'+widget.icon"/></svg></span>
                                <span><strong x-text="widgetTitle(widget)"></strong><small x-text="widgetDescription(widget)"></small></span>
                            </button>
                        </template>
                        {{-- Pages other plugins add to the server panel. --}}
                        <template x-if="server?.external_pages?.length">
                            <span class="ps-widget-group">External</span>
                        </template>
                        <template x-for="page in server?.external_pages || []" :key="page.key">
                            <button type="button" class="ps-widget" style="--ps-tone: #2dd4bf" :aria-current="modal==='external' && externalPage?.key===page.key ? 'page' : null" x-on:click="openExternal(page)" :aria-label="page.label+' — from '+page.plugin" :data-tip="'From the '+page.plugin+' plugin'">
                                <span class="ps-widget-icon"><svg aria-hidden="true"><use href="#ps-plugins"/></svg></span>
                                <span><strong x-text="page.label"></strong></span>
                            </button>
                        </template>
                    </nav>
                    {{-- Phones: four tabs that always fit. Console and the two most used sections, the rest under More. --}}
                    <nav class="ps-phone-sections" aria-label="Server sections" x-on:click.outside="phoneMore=false" x-on:keydown.escape.stop="phoneMore=false">
                        <button type="button" class="ps-phone-section" :aria-current="modal ? null : 'page'" x-on:click="phoneMore=false; modal ? close() : $refs.output.closest('.ps-console').scrollIntoView({behavior: 'smooth', block: 'start'})"><svg class="ps-phone-section-icon" aria-hidden="true"><use href="#ps-terminal"/></svg><span>Console</span></button>
                        <template x-for="widget in widgets.filter((w) => PHONE_SECTIONS.includes(w.key))" :key="widget.key">
                            <button type="button" class="ps-phone-section" x-show="showWidget(widget.key)" :aria-current="modal===widget.key ? 'page' : null" x-on:click="phoneMore=false; modal===widget.key || open(widget.key)"><svg class="ps-phone-section-icon" aria-hidden="true"><use :href="'#ps-'+widget.icon"/></svg><span x-text="widget.key==='players' ? 'Players' : widgetTitle(widget)"></span></button>
                        </template>
                        <div class="ps-phone-more">
                            <button type="button" class="ps-phone-section" aria-controls="ps-phone-more-menu" :aria-expanded="phoneMore" :aria-current="phoneMoreActive() ? 'page' : null" x-on:click="phoneMore=!phoneMore"><svg class="ps-phone-section-icon" aria-hidden="true"><use href="#ps-dots"/></svg><span>More</span></button>
                            <div id="ps-phone-more-menu" class="ps-dropdown is-end ps-phone-more-menu" x-show="phoneMore" x-cloak x-transition.opacity>
                                <template x-for="widget in widgets.filter((w) => !PHONE_SECTIONS.includes(w.key))" :key="widget.key">
                                    <button type="button" class="ps-menu-item" x-show="showWidget(widget.key)" :aria-current="modal===widget.key ? 'page' : null" x-on:click="phoneMore=false; modal===widget.key || open(widget.key)">
                                        <svg aria-hidden="true"><use :href="'#ps-'+widget.icon"/></svg><span x-text="widgetTitle(widget)"></span>
                                    </button>
                                </template>
                                <template x-for="page in server?.external_pages || []" :key="page.key">
                                    <button type="button" class="ps-menu-item" x-on:click="phoneMore=false; openExternal(page)">
                                        <svg aria-hidden="true"><use href="#ps-plugins"/></svg><span x-text="page.label"></span>
                                    </button>
                                </template>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="ps-live-column">
                    <aside class="ps-console" x-show="server" :class="{'can-explain': canExplain()}">
                        <div class="ps-console-title">
                            <span class="ps-terminal-icon" aria-hidden="true">›_</span>
                            <strong x-text="installView() ? 'Installation log' : 'Live console'">Live console</strong>
                            <span class="ps-console-dot" :class="{'connected': connected}"></span><span class="ps-live-bars" x-show="connected" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
                            <span class="ps-console-state" x-text="connected ? 'Connected to Wings' : 'Connecting to Wings…'"></span>
                            {{-- Buttons other plugins add to Pelican's console (such as Upload logs from Mclogs Uploader). --}}
                            <template x-for="action in pluginActions('server')" :key="action.key">
                                <button type="button" class="ps-console-clear ps-console-plugin-action" :disabled="action.disabled || pluginActionBusy===action.key" :aria-busy="pluginActionBusy===action.key" x-on:click="runPluginAction(action)" :data-tip="action.label+(action.plugin ? ' — from the '+action.plugin+' plugin' : ' — from another plugin')" :aria-label="action.label">
                                    <span class="ps-plugin-action-icon" x-show="action.icon" x-html="action.icon" aria-hidden="true"></span><span x-text="action.label"></span>
                                </button>
                            </template>
                            <button type="button" class="ps-console-clear" x-on:click="logs=[]; renderLogs()">Clear</button>
                            {{-- Explain this error: only once an admin saved an AI API key (Claude, GPT or Gemini) in Simplify settings. --}}
                            <button type="button" class="ps-console-clear ps-console-tool ps-console-explain" x-show="canExplain()" x-on:click="explainError('console')" :disabled="!!explain?.loading" data-tip="Explain what went wrong, from the last console lines" aria-label="Explain this error"><svg aria-hidden="true"><use href="#ps-question"/></svg><span>Explain</span></button>
                            <button type="button" class="ps-console-clear ps-console-tool ps-console-grow" x-show="!docked() && !consoleWindow" x-on:click="setConsoleFocus(!consoleFocus)" :aria-pressed="consoleFocus" :data-tip="consoleFocus ? 'Normal size' : 'Bigger console'" :aria-label="consoleFocus ? 'Normal size' : 'Bigger console'"><svg aria-hidden="true"><use href="#ps-expand"/></svg></button>
                            <button type="button" class="ps-console-clear ps-console-tool ps-console-window" x-show="!docked() && !consoleWindow && !embedded" x-on:click="openConsoleWindow()" data-tip="Open in a new window" aria-label="Open the console in a new window"><svg aria-hidden="true"><use href="#ps-external"/></svg></button>
                            <button type="button" class="ps-console-clear ps-console-tool ps-console-peek" x-show="docked()" x-on:click="setConsolePeek(!consolePeek)" :aria-pressed="consolePeek" :data-tip="consolePeek ? 'Hide the log' : 'Show the last log lines'" :aria-label="consolePeek ? 'Hide the log' : 'Show the last log lines'"><svg aria-hidden="true"><use href="#ps-chevron"/></svg></button>
                            <button type="button" class="ps-console-clear ps-console-tool ps-console-full" x-show="docked()" x-on:click="close()"><svg aria-hidden="true"><use href="#ps-expand"/></svg><span>Full console</span></button>
                        </div>
                        <pre wire:ignore class="ps-console-output" x-ref="output" tabindex="0" aria-label="Server console output"></pre>
                        <div class="ps-quick-commands" x-show="server?.minecraft" role="group" aria-label="Quick commands" x-init="scrollHint($el)">
                            <template x-for="quick in QUICK_COMMANDS" :key="quick">
                                <button type="button" class="ps-quick-command" :disabled="!connected || !server?.permissions['control.console']" x-on:click="useQuickCommand(quick)" x-text="quick.endsWith(' ') ? quick+'…' : quick"></button>
                            </template>
                        </div>
                        <form class="ps-command" x-on:submit.prevent="sendCommand()">
                            <span aria-hidden="true">›</span>
                            <input x-model="command" placeholder="Type a command…" :disabled="!connected || !server?.permissions['control.console']" x-on:keydown.up.prevent="historyBack()" x-on:keydown.down.prevent="historyForward()" aria-label="Console command">
                            <button type="submit" :disabled="!connected || !server?.permissions['control.console']" aria-label="Send command">↵</button>
                        </form>
                    </aside>
                </div>
            </div>
        </section>
    </main>

    {{-- Phone tab bar (overview only): servers, create and the panel menu within thumb reach. --}}
    <nav class="ps-tabbar" x-show="!server && !hostMode" aria-label="Phone navigation" x-on:click.outside="createMenu=false" x-on:keydown.escape.stop="createMenu=false">
        <button type="button" class="ps-tab is-active" aria-current="page" x-on:click="createMenu=false; navMenu=false; scrollTo({top: 0, behavior: 'smooth'})">
            <svg aria-hidden="true"><use href="#ps-host"/></svg><span>Servers</span>
        </button>
        <div class="ps-tab-create" x-show="boot.can_create">
            <button type="button" class="ps-tab" aria-haspopup="dialog" :aria-expanded="createMenu" x-on:click="navMenu=false; createChoices().length===1 ? openCreate(createChoices()[0].key) : (createMenu=!createMenu)">
                <span class="ps-tab-plus" :class="{'is-pumpkin': halloween()}"><svg aria-hidden="true" x-show="!halloween()"><use href="#ps-plus"/></svg><svg class="ps-hw-tab" viewBox="0 3 24 18" aria-hidden="true" x-show="halloween()" x-cloak><path class="ps-hw-body" d="M12 6.5c-1.6-.9-3.6-1-5.3-.2C3.8 7.6 2.5 10.7 3.3 14c.8 3.4 3.6 5.6 6.4 5.4.8 0 1.6-.3 2.3-.7.7.4 1.5.7 2.3.7 2.8.2 5.6-2 6.4-5.4.8-3.3-.5-6.4-3.4-7.7-1.7-.8-3.7-.7-5.3.2z"/><path class="ps-hw-ribs" d="M8.2 7.2c-1.4 3-1.4 7.5.6 11.6M15.8 7.2c1.4 3 1.4 7.5-.6 11.6"/><path class="ps-hw-stem" d="M12 6.5c0-1.6.6-2.8 2-3.6"/><path class="ps-hw-carve" d="M12 9.6v6.4M8.8 12.8h6.4"/></svg></span><span>New</span>
            </button>
            <div class="ps-dropdown ps-tab-create-menu" x-show="createMenu" x-cloak x-transition.opacity role="menu">
                <template x-for="choice in createChoices()" :key="choice.key">
                    <button type="button" class="ps-menu-item" role="menuitem" x-on:click="createMenu=false; openCreate(choice.key)">
                        <svg aria-hidden="true"><use :href="'#ps-'+choice.icon"/></svg><span x-text="choice.label"></span>
                    </button>
                </template>
            </div>
        </div>
        <button type="button" class="ps-tab" aria-controls="ps-navigation-items" :aria-expanded="navMenu" x-on:click.stop="createMenu=false; accountMenu=false; navMenu=!navMenu">
            <svg aria-hidden="true"><use href="#ps-menu"/></svg><span>Menu</span>
        </button>
    </nav>

    {{-- A plugin button running in its own panel: invisible until its dialog opens, which then shows over Simplify. --}}
    <template x-if="pluginActionFrame">
        <div class="ps-plugin-action-layer" :class="{'is-open': pluginActionOpen}">
            <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="pluginActionFrame.url" title="Plugin action" x-on:load="pluginActionLoaded($el)"></iframe>
        </div>
    </template>

    {{-- Workspace popup: one shell with fixed sizes (sm, md, lg); only the body scrolls. ------------------- --}}
    <div class="ps-modal-layer" :data-open="!!modal && !docked()" :data-docked="docked()" x-show="modal" x-cloak>
        <section class="ps-modal" :class="modalSize()" x-on:touchstart="sheetStart($event)" x-on:touchmove="sheetMove($event)" x-on:touchend="sheetEnd()" x-on:touchcancel="sheetEnd()" :role="docked() ? 'region' : 'dialog'" :aria-modal="modal && !docked() ? 'true' : null" :aria-label="modalTitle()" x-trap.noscroll="modal && !docked()">
            <header class="ps-modal-head">
                <h2 x-text="modalTitle()"></h2>
                <button type="button" class="ps-btn is-sm is-icon is-subtle" x-show="modal==='files' && server?.files_url" x-on:click="window.open(server.files_url, 'ps-files-'+server.uuid, 'popup,width=1280,height=860')" data-tip="Open in a separate window" aria-label="Open file manager in a separate window"><svg aria-hidden="true"><use href="#ps-external"/></svg></button>
                <div class="ps-sftp-inline" x-show="modal==='files' && server?.sftp">
                    <button type="button" class="ps-btn is-sm ps-sftp-toggle" x-on:click="sftpOpen=!sftpOpen" :aria-expanded="sftpOpen" aria-controls="ps-sftp-details" x-text="sftpOpen ? 'Hide SFTP details' : 'Show SFTP details'"></button>
                    <span id="ps-sftp-details" class="ps-sftp-details" x-show="sftpOpen" x-cloak>
                        <button type="button" class="ps-sftp-value" x-on:click="copyText(server.sftp.username, 'Username copied')" data-tip="Copy SFTP username"><span x-text="server?.sftp?.username"></span><svg aria-hidden="true"><use href="#ps-copy"/></svg></button>
                        <small>Password: your panel password</small>
                        <a class="ps-sftp-connect" :href="sftpLink()" data-tip="Open SFTP connection"><span x-text="server?.sftp?.url"></span><svg aria-hidden="true"><use href="#ps-link"/></svg></a>
                    </span>
                </div>
                <button type="button" class="ps-btn is-icon is-subtle ps-close" x-on:click="close()" aria-label="Close dialog"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
            </header>

            <div class="ps-modal-body" :class="{'is-flush': modalFlush()}">
                <div x-show="loading" class="ps-modal-loading" role="status"><span class="ps-spinner"></span><span>Loading your workspace…</span></div>

                <template x-if="modal==='create'">
                    <iframe :data-ps-frame="createFrameKind()" :data-ps-accent="currentAccentHex()" :src="createFrameUrl()" title="Create server" x-on:load="createFrameLoaded($el)"></iframe>
                </template>
                <template x-if="modal==='panel-settings'">
                    <iframe data-ps-frame="settings" :data-ps-accent="currentAccentHex()" :src="panelSettingsUrl()" title="Simplify settings" x-on:load="panelSettingsLoaded($el)"></iframe>
                </template>
                <template x-if="modal==='external' && externalPage">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(externalPage.url)" :title="externalPage.label" x-on:load="styleFrame($el, 'native'); loading=false"></iframe>
                </template>
                <template x-if="modal==='admin-page' && adminPage">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(adminPage.url)" :title="adminPage.label" x-on:load="styleFrame($el, 'native')"></iframe>
                </template>
                <template x-if="modal==='account'">
                    <iframe data-ps-frame="account" :data-ps-accent="currentAccentHex()" :src="frameUrl(boot.profile_url)" title="Profile" x-on:load="styleFrame($el, 'account')"></iframe>
                </template>

                {{-- Every notification: what an admin pinned on top, then the rest with "Show more"; a full-screen sheet on phones. --}}
                <div x-show="modal==='inbox'" class="ps-inbox">
                    <div class="ps-inbox-bar">
                        <span class="ps-help" x-text="unreadNotifications() ? unreadNotifications()+' unread' : 'Everything is read.'"></span>
                        <button type="button" class="ps-btn is-sm" x-show="announcementsPage()" x-on:click="newAnnouncement()"><svg aria-hidden="true"><use href="#ps-plus"/></svg>New announcement</button>
                        <button type="button" class="ps-btn is-sm is-subtle" x-show="unreadNotifications()" x-on:click="markAllNotificationsRead()"><svg aria-hidden="true"><use href="#ps-check"/></svg>Mark all read</button>
                        <button type="button" class="ps-btn is-sm is-subtle" x-show="canClearRead()" x-on:click="clearReadNotifications()" data-tip="Moves read notifications to Archived; pinned ones stay">Clear read</button>
                    </div>
                    <template x-if="modal==='inbox'">
                        <div>@include('pelican-simplify::notification-items', ['archive' => true])</div>
                    </template>
                </div>

                {{-- Alias --}}
                {{-- App notifications on this and the account's other devices (Web Push through the installed app or browser). --}}
                <div x-show="modal==='notifications'" class="ps-customize ps-push">
                    <p class="ps-help" x-show="pushNeedsInstall()">On iPhone and iPad, notifications only work in the installed app: tap Share, then Add to Home Screen, and open the panel from there.</p>
                    <p class="ps-help" x-show="!pushSupported() && !pushNeedsInstall()">This browser cannot show notifications from the panel. Try Chrome, Edge, Firefox or Safari, over https.</p>
                    <p class="ps-error" x-show="push.error" x-text="push.error"></p>
                    <template x-if="pushSupported()">
                        <div>
                            <span class="ps-label">This device</span>
                            <button type="button" class="ps-customize-switch" role="switch" :aria-checked="pushOn()" :disabled="push.busy || !push.settings" x-on:click="pushOn() ? disablePush() : enablePush()">
                                <span><strong>Notifications on this device</strong><small x-text="pushBlocked() ? 'Blocked in the browser\'s site settings' : deviceLabel()"></small></span>
                                <span class="ps-switch" :class="{'is-on': pushOn()}" aria-hidden="true"></span>
                            </button>
                            <div class="ps-customize-row">
                                <div><strong>Test notification</strong><small>Sends a test to this device right now, so you can see that it works.</small></div>
                                <button type="button" class="ps-btn is-sm" x-on:click="testPush()" :disabled="!pushOn() || push.busy">Send test</button>
                            </div>
                        </div>
                    </template>
                    <template x-if="push.settings">
                        <div>
                            <span class="ps-label">What you get</span>
                            <button type="button" class="ps-customize-switch" role="switch" :aria-checked="!!push.settings.preferences.announcements" x-on:click="setPushPreference('announcements', !push.settings.preferences.announcements)">
                                <span><strong>Announcements</strong><small>Info, Warning and Success messages that admins send as app notification.</small></span>
                                <span class="ps-switch" :class="{'is-on': push.settings.preferences.announcements}" aria-hidden="true"></span>
                            </button>
                            <button type="button" class="ps-customize-switch" role="switch" x-show="push.settings.admin" :aria-checked="!!push.settings.preferences.updates" x-on:click="setPushPreference('updates', !push.settings.preferences.updates)">
                                <span><strong>Updates</strong><small>A new version of Simplify, a plugin, Wings or Pelican (root admins).</small></span>
                                <span class="ps-switch" :class="{'is-on': push.settings.preferences.updates}" aria-hidden="true"></span>
                            </button>
                            <template x-if="push.settings.devices.some((device) => !device.current)">
                                <div>
                                    <span class="ps-label">Your other devices</span>
                                    <template x-for="device in push.settings.devices.filter((device) => !device.current)" :key="device.id">
                                        <div class="ps-customize-row">
                                            <div><strong x-text="device.label"></strong><small x-text="pushDeviceTime(device)"></small></div>
                                            <button type="button" class="ps-btn is-sm is-subtle" x-on:click="removePushDevice(device.id)">Remove</button>
                                        </div>
                                    </template>
                                </div>
                            </template>
                        </div>
                    </template>
                </div>
                <template x-if="modal==='alias'">
                    <div>
                        <label class="ps-field">Server alias<input x-model="aliasDraft" maxlength="80" placeholder="Leave empty to use the server name" x-on:keydown.enter="saveAlias()"></label>
                        <p class="ps-help">The actual server name stays unchanged. Clear the alias to show the server name as the title.</p>
                    </div>
                </template>

                {{-- Background --}}
                <template x-if="modal==='background'">
                    <div>
                        <p class="ps-help">Choose the artwork for this server’s overview card and dashboard.</p>
                        <div class="ps-background-grid">
                            <button type="button" class="ps-background-choice ps-background-auto" :aria-pressed="backgroundDraft==='auto'" x-on:click="backgroundDraft='auto'" :disabled="busy">
                                <svg aria-hidden="true"><use href="#ps-image"/></svg><strong>Automatic</strong><small>A consistent image for this server</small>
                            </button>
                            <button type="button" class="ps-background-choice ps-background-auto" :aria-pressed="backgroundDraft==='none'" x-on:click="backgroundDraft='none'" :disabled="busy">
                                <strong>No background</strong><small>Keep it simple</small>
                            </button>
                            <button type="button" class="ps-background-choice ps-background-auto ps-background-color" :class="{'is-auto': true}" :aria-pressed="backgroundDraft==='color'" x-on:click="backgroundDraft='color'" :disabled="busy">
                                <span class="ps-banner-swatch ps-banner-color is-auto"></span><strong>Accent colour</strong><small>A colour that stands out but matches the accent</small>
                            </button>
                            <label class="ps-background-choice ps-background-auto ps-background-color" :aria-pressed="backgroundDraft.startsWith('color:') ? 'true' : 'false'">
                                <span class="ps-banner-swatch ps-banner-color" :style="{'--ps-banner': backgroundDraft.startsWith('color:') ? backgroundDraft.slice(6) : '#7c3aed'}"></span><strong>Your own colour</strong><small>Click to pick a colour</small>
                                <input type="color" class="ps-visually-hidden" :value="backgroundDraft.startsWith('color:') ? backgroundDraft.slice(6) : '#7c3aed'" x-on:input="backgroundDraft='color:'+$event.target.value.toLowerCase()" :disabled="busy" aria-label="Pick a banner colour">
                            </label>
                            <template x-for="image in boot.background_choices || []" :key="image.id">
                                <button type="button" class="ps-background-choice" :aria-pressed="backgroundDraft===image.id" x-on:click="backgroundDraft=image.id" :disabled="busy"><img :src="image.url" :alt="image.name" loading="lazy"><strong x-text="image.name"></strong></button>
                            </template>
                        </div>
                        <h3 class="ps-section-title">Your uploaded banners</h3>
                        <div class="ps-background-grid">
                            <template x-for="image in uploadedBackgrounds" :key="image.id">
                                <article class="ps-uploaded-banner">
                                    <button type="button" class="ps-background-choice" :aria-pressed="backgroundDraft===image.id" x-on:click="backgroundDraft=image.id" :disabled="busy"><img :src="image.url" :alt="image.name" loading="lazy"><strong x-text="image.name"></strong></button>
                                    <button type="button" class="ps-btn is-sm is-danger" x-on:click="deleteBanner(image.id)" :disabled="busy">Remove</button>
                                </article>
                            </template>
                        </div>
                        <p class="ps-help" x-show="!uploadedBackgrounds.length">No uploaded banners yet.</p>
                        <label class="ps-field">Upload a banner<input type="file" accept="image/png,image/jpeg,image/webp" wire:model="bannerUpload" x-on:change.capture="bannerUploadChanged($event)" x-on:livewire-upload-error="toast('Upload failed. Check PHP, Livewire and NGINX upload limits in System checks.', 'danger')"></label>
                        @error('bannerUpload')<p class="ps-alert is-danger">{{ $message }}</p>@enderror
                        <p class="ps-help">JPG, PNG or WebP · up to {{ \Simplify\Panel\Services\UploadLimits::label(\Simplify\Panel\Services\UploadLimits::bannerBytes()) }} (PHP/Livewire; your proxy may be lower). Wide images work best.</p>
                        <button type="button" class="ps-btn" x-on:click="uploadBanner()" :disabled="busy" wire:loading.attr="disabled" wire:target="bannerUpload,uploadServerBanner"><svg aria-hidden="true"><use href="#ps-download"/></svg>Upload and use banner</button>
                    </div>
                </template>

                {{-- Game settings: tabs on the left, one save action in the footer. --}}
                <div x-show="modal==='settings' && !loading" class="ps-settings-workspace" :class="{'has-tabs': server?.minecraft}">
                    <nav class="ps-tabs" x-show="server?.minecraft" aria-label="Settings sections" x-init="scrollHint($el)">
                        <template x-for="tab in settingsTabs()" :key="tab.key">
                            <button type="button" :aria-pressed="settingsTab===tab.key" x-on:click="settingsTab=tab.key"><svg aria-hidden="true"><use :href="'#ps-'+tab.icon"/></svg><span x-text="tab.label"></span></button>
                        </template>
                    </nav>
                    <div class="ps-tab-panels">
                        <section x-show="settingsTab==='general' || !server?.minecraft">
                            <h3 class="ps-section-title">Server identity</h3>
                            <label class="ps-field">Server name
                                <span class="ps-input-row"><input x-model="name" maxlength="255"><button type="button" class="ps-btn" x-on:click="renameServer()" :disabled="busy || !server?.permissions['settings.rename']">Rename</button></span>
                            </label>
                            <label class="ps-field">Display alias
                                <span class="ps-input-row"><input x-model="aliasDraft" maxlength="80" placeholder="Leave empty to use the server name"><button type="button" class="ps-btn" x-on:click="saveAlias()" :disabled="busy || !server?.permissions['settings.rename']">Save alias</button></span>
                            </label>
                            <p class="ps-help">Name and alias are saved immediately and do not need a restart.</p>
                            <template x-if="server?.minecraft">
                                <div>
                                    <h3 class="ps-section-title">Server icon</h3>
                                    <label class="ps-field">64 × 64 PNG<input type="file" accept="image/png" wire:model="iconUpload"></label>
                                    <p class="ps-help">The icon is uploaded with your other saved settings at the next restart.</p>
                                </div>
                            </template>
                        </section>
                        <section x-show="settingsTab==='gameplay' && server?.minecraft">
                            <h3 class="ps-section-title">Gameplay</h3>
                            <div class="ps-grid-2">
                                <label class="ps-field">Maximum players<input type="number" min="1" max="1000" x-model.number="settings.max_players"></label>
                                <label class="ps-field">Difficulty<select x-model="settings.difficulty"><option>peaceful</option><option>easy</option><option>normal</option><option>hard</option></select></label>
                                <label class="ps-field">Game mode<select x-model="settings.gamemode"><option>survival</option><option>creative</option><option>adventure</option><option>spectator</option></select></label>
                                <label class="ps-field">View distance<input type="number" min="2" max="32" x-model.number="settings.view_distance"></label>
                                <label class="ps-field">Spawn protection<input type="number" min="0" max="1000" x-model.number="settings.spawn_protection"></label>
                            </div>
                            <h3 class="ps-section-title">Rules</h3>
                            <div class="ps-checks">
                                <label class="ps-check"><input type="checkbox" role="switch" x-model="settings.pvp"> PvP</label>
                                <label class="ps-check"><input type="checkbox" role="switch" x-model="settings.white_list"> Whitelist</label>
                                <label class="ps-check"><input type="checkbox" role="switch" x-model="settings.allow_flight"> Allow flight</label>
                            </div>
                        </section>
                        <section x-show="settingsTab==='motd' && server?.minecraft" class="ps-motd-editor">
                            <h3 class="ps-section-title">Message of the day</h3>
                            <div class="ps-motd" x-data="psMotdEditor({ name: () => server?.alias || server?.name, icon: () => safeImage(server?.server_icon) })" x-modelable="value" x-model="settings.motd">
                                @include('pelican-simplify::motd-editor')
                            </div>
                        </section>
                        <p x-show="server?.minecraft && !server?.properties_available" class="ps-alert is-warn">Settings are available after server.properties has been created.</p>
                    </div>
                </div>

                {{-- Performance --}}
                <div x-show="modal==='performance' && !loading">
                    <p class="ps-help">Allocated CPU, memory and storage for this server.</p>
                    <dl class="ps-kv">
                        <dt>CPU limit</dt><dd x-text="server?.cpu ? server.cpu+'%' : 'Unlimited'"></dd>
                        <dt>Memory limit</dt><dd x-text="server?.memory ? bytes(server.memory*1048576) : 'Unlimited'"></dd>
                        <dt>Storage limit</dt><dd x-text="server?.disk ? bytes(server.disk*1048576) : 'Unlimited'"></dd>
                    </dl>
                    <section x-show="server?.can_resources">
                        <h3 class="ps-section-title">Change resources</h3>
                        <template x-for="group in resourceGroups" :key="group.key">
                            <div class="ps-resource-group">
                                <span class="ps-field" x-text="group.label"></span>
                                <div class="ps-choice-cards" role="radiogroup" :aria-label="group.label">
                                    <template x-for="option in [...group.presets, ['custom', 'Custom', 'Choose your own']]" :key="option[0]">
                                        <button type="button" role="radio" class="ps-choice" :aria-checked="String(resourceChoice(group) === option[0])" x-on:click="pickResource(group, option[0])">
                                            <svg aria-hidden="true"><use :href="'#ps-' + group.icon"/></svg>
                                            <span class="ps-choice-title" x-text="option[1]"></span>
                                            <span class="ps-choice-description" x-text="option[2]"></span>
                                        </button>
                                    </template>
                                </div>
                                <label class="ps-field" x-show="resourceChoice(group) === 'custom'"><span x-text="group.custom + (resourceMin(group) === 0 ? ' · 0 = unlimited' : '')"></span><input type="number" step="any" :min="resourceMin(group)" :max="group.max" x-model.number="settings[group.key]"></label>
                            </div>
                        </template>
                        <p class="ps-help" x-text="installFailed() ? 'The new limits are used when you try the installation again.' : 'Save changes, then apply them with a restart.'"></p>
                    </section>
                    <p class="ps-help" x-show="!server?.can_resources">Ask an administrator to change these limits.</p>
                </div>

                {{-- Files: fixed workspace, each iframe scrolls on its own. --}}
                <div x-show="modal==='files' && !loading" class="ps-files-workspace" :class="{'has-editor': !!fileEditorUrl}">
                    <div class="ps-files-list">
                        <iframe x-ref="filesFrame" data-ps-frame="files" :data-ps-accent="currentAccentHex()" :src="modal==='files' ? frameUrl(filesStartUrl()) : 'about:blank'" x-on:load="filesFrameLoaded($el)" title="Server file manager"></iframe>
                    </div>
                    <template x-if="fileEditorUrl">
                        <section class="ps-file-editor">
                            <header>
                                <svg class="ps-file-editor-icon" aria-hidden="true"><use href="#ps-file"/></svg>
                                <strong class="ps-file-editor-path" :data-tip="fileEditorPath" x-text="fileEditorPath.split('/').pop() || fileEditorPath"></strong>
                                <span class="ps-badge is-warn" x-show="fileEditorDirty">Unsaved</span>
                                <span class="ps-file-editor-actions">
                                    <button type="button" class="ps-btn is-sm is-primary" x-show="fileEditorExternal" :disabled="fileEditorChecking || fileEditorSaving" x-on:click="saveFileEditor()" data-tip="Save and close (Ctrl+S)"><svg aria-hidden="true"><use href="#ps-save"/></svg><span>Save</span></button>
                                    <button type="button" class="ps-btn is-icon is-sm is-subtle" x-on:click="closeFileEditor()" data-tip="Close editor" aria-label="Close file editor"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
                                </span>
                            </header>
                            <iframe data-ps-frame="editor" :data-ps-accent="currentAccentHex()" :src="fileEditorUrl" x-on:load="fileEditorLoaded($el)" title="File editor"></iframe>
                        </section>
                    </template>
                </div>

                {{-- Backups --}}
                <div x-show="modal==='backups' && !loading">
                    <div class="ps-panel ps-backup-policy">
                        <svg aria-hidden="true"><use href="#ps-backups"/></svg>
                        <div>
                            <strong>Automatic backups</strong>
                            <p x-text="backupPolicyLabel()"></p>
                            <small>A failed backup never replaces a successful recovery point.</small>
                        </div>
                    </div>
                    <div x-show="server?.root_admin" class="ps-admin-options">
                        <h3 class="ps-section-title">Admin options</h3>
                        <div class="ps-grid-2">
                            <label class="ps-field">Interval · minutes<input type="number" min="30" x-model.number="backupSettings.interval_minutes"></label>
                            <label class="ps-field">Recovery points<input type="number" min="1" max="100" x-model.number="backupSettings.retention"></label>
                        </div>
                        <div class="ps-input-row">
                            <label class="ps-check"><input type="checkbox" role="switch" x-model="backupSettings.enabled"> Automatic backups enabled</label>
                            <label class="ps-check"><input type="checkbox" role="switch" x-model="backupSettings.only_when_used"> Skip while the server has not run</label>
                            <button type="button" class="ps-btn is-primary" x-on:click="saveBackups()" :disabled="busy">Save backup policy</button>
                        </div>
                    </div>
                    <p class="ps-alert is-warn" x-show="!backups.configured">Backup storage is not configured yet. Ask an administrator to configure a backup host in Pelican.</p>
                    <h3 class="ps-section-title">Recovery points</h3>
                    <div class="ps-rows">
                        <template x-for="b in backups.items" :key="b.uuid">
                            <div>
                                <span><strong x-text="b.name"></strong><small x-text="b.completed ? (b.successful ? bytes(b.bytes) : 'Failed') : 'In progress'"></small></span>
                                <button type="button" class="ps-btn is-sm" x-on:click="downloadBackup(b.uuid)" :disabled="busy || !b.successful || !b.completed || !server?.permissions['backup.download']"><svg aria-hidden="true"><use href="#ps-download"/></svg>Download</button>
                                <button type="button" class="ps-btn is-sm" x-on:click="restoreBackup(b.uuid)" :disabled="busy || status!=='offline' || !b.successful || !b.completed || !server?.permissions['backup.restore']"><svg aria-hidden="true"><use href="#ps-restart"/></svg>Restore</button>
                            </div>
                        </template>
                    </div>
                    <p x-show="!backups.items.length" class="ps-empty">Your first automatic backup will appear here.</p>
                    <div x-show="server?.root_admin">
                        <h3 class="ps-section-title">Full backup management · admin</h3>
                        <iframe class="ps-embedded-frame" x-ref="backupFrame" data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="modal==='backups' && server?.root_admin ? frameUrl(server?.backups_url) : 'about:blank'" x-on:load="styleFrame($el, 'native')" title="Admin backup management"></iframe>
                    </div>
                </div>

                {{-- Players --}}
                <div x-show="modal==='players' && !loading">
                    <div class="ps-player-actions">
                        <label class="ps-field">Player name<input x-model="playerName" maxlength="16" placeholder="Minecraft username"></label>
                        <div class="ps-action-wrap">
                            <template x-for="action in ['Whitelist','Unwhitelist','OP','DeOP','Kick','Ban','Unban']">
                                <button type="button" class="ps-btn is-sm" :class="{'is-danger': ['Kick','Ban'].includes(action)}" x-on:click="playerAction(action)" :disabled="!connected || status!=='running' || !server?.permissions['control.console']" x-text="action"></button>
                            </template>
                        </div>
                    </div>
                    <h3 class="ps-section-title">Online players</h3>
                    <p class="ps-help">Servers may hide player names in their status response.</p>
                    <div class="ps-player-list">
                        <template x-for="p in server?.player_names || []" :key="p.name">
                            <button type="button" x-on:click="playerName=p.name"><img :src="head(p)" :alt="p.name" loading="lazy"><span x-text="p.name"></span><span class="ps-badge is-ok">Online</span></button>
                        </template>
                    </div>
                    <p x-show="!server?.player_names?.length" class="ps-empty">No player names reported.</p>
                    <template x-for="[key,title] in [['whitelist','Whitelist'],['ops','Operators'],['banned-players','Banned players']]">
                        <section>
                            <h3 class="ps-section-title" x-text="title"></h3>
                            <div class="ps-player-list">
                                <template x-for="p in playerLists[key] || []" :key="p.name">
                                    <button type="button" x-on:click="playerName=p.name"><img :src="head(p)" :alt="p.name" loading="lazy"><span x-text="p.name"></span></button>
                                </template>
                            </div>
                            <p class="ps-help" x-show="!(playerLists[key] || []).length">Nobody yet.</p>
                        </section>
                    </template>
                </div>

                {{-- Plugins and mods on one page: search on the left (Modrinth, Hangar, SpigotMC), what is installed on the right. --}}
                <div x-show="isPackageModal() && !loading" class="ps-packages">
                    <p class="ps-alert is-warn" x-show="status!=='offline'"><svg aria-hidden="true"><use href="#ps-info"/></svg><span x-text="'Stop the server to add, update or remove ' + modal + '.'"></span></p>
                    <div class="ps-packages-layout">
                        <section class="ps-packages-add" :aria-label="modal==='plugins' ? 'Add plugin' : 'Add mod'">
                            <form class="ps-input-row ps-package-search" x-on:submit.prevent="searchPackages()">
                                <input class="ps-input" type="search" x-model="packageQuery" :placeholder="modal==='plugins' ? 'Search plugins…' : 'Search mods…'" :aria-label="modal==='plugins' ? 'Search plugins' : 'Search mods'">
                                <input class="ps-input ps-version-input" x-show="!installed.context?.version" x-model="packageVersion" placeholder="Minecraft version" aria-label="Minecraft version">
                                <button type="submit" class="ps-btn is-primary" :disabled="busy"><svg aria-hidden="true"><use href="#ps-search"/></svg>Search</button>
                            </form>
                            <div class="ps-chips" x-show="packageSites().length > 2" role="group" aria-label="Sites">
                                <template x-for="site in packageSites()" :key="site.key">
                                    <button type="button" class="ps-chip" :aria-pressed="packageSite===site.key" x-on:click="packageSite=site.key" x-text="site.label"></button>
                                </template>
                            </div>
                            <p class="ps-help ps-curseforge-own" x-show="installed.context?.curseforge_own">
                                <span x-text="installed.context?.curseforge_mine ? 'CurseForge uses your own API key.' : (installed.context?.curseforge ? 'CurseForge uses the key of this panel.' : 'Add a CurseForge API key to search CurseForge too.')"></span>
                                <button type="button" class="ps-link" x-on:click="setCurseForgeKey()" x-text="installed.context?.curseforge_mine ? 'Change or remove' : 'Use my own key'"></button>
                            </p>
                            <h3 class="ps-section-title" x-text="packageHeading()"></h3>
                            <p class="ps-help" x-show="packageSearching">Searching…</p>
                            <div class="ps-package-list">
                                <template x-for="p in visiblePackages()" :key="p.key">
                                    <article class="ps-package">
                                        <img :src="p.icon ? safeImage(p.icon) : boot.favicon_url" alt="" loading="lazy" :class="{'is-placeholder': !p.icon}">
                                        <div>
                                            <strong x-text="p.title"></strong><small x-show="p.author" x-text="' by ' + p.author"></small>
                                            <p x-text="p.description"></p>
                                            <div class="ps-package-meta">
                                                <a class="ps-source" :class="'is-' + p.source" :href="safeLink(p.page)" target="_blank" rel="noopener noreferrer" x-text="packageDetail(p)?.via ? p.label + ' via GitHub' : p.label"></a>
                                                <span x-show="packageDetail(p)?.version" x-text="versionLabel(packageDetail(p)?.version)"></span>
                                                <span x-show="packageDetail(p)?.for" x-text="'for ' + packageDetail(p)?.for"></span>
                                                <span class="ps-badge is-warn" x-show="packageDetail(p) && !packageDetail(p).fits"><svg aria-hidden="true"><use href="#ps-alert"/></svg><span x-text="'Not made for ' + packageVersion"></span></span>
                                                <span class="ps-package-also" x-show="p.also.length">Also on <template x-for="(o, i) in p.also" :key="o.key"><span><button type="button" class="ps-link" x-on:click="useSource(p, o)" x-text="o.label"></button><span x-show="i < p.also.length - 1">, </span></span></template></span>
                                            </div>
                                        </div>
                                        <span class="ps-badge is-ok" x-show="installedKey(p.key)"><svg aria-hidden="true"><use href="#ps-check"/></svg>Installed</span>
                                        <button type="button" class="ps-btn is-sm" x-show="!installedKey(p.key) && packageDetail(p)?.installable !== false" :class="{'is-primary': packageDetail(p)?.fits}" x-on:click="installPackage(p)" :disabled="busy || status!=='offline' || !packageDetail(p)" x-text="packageDetail(p) && !packageDetail(p).fits ? 'Install anyway' : 'Install'"></button>
                                        <a class="ps-btn is-sm" x-show="!installedKey(p.key) && packageDetail(p)?.installable === false" :href="safeLink(p.page)" target="_blank" rel="noopener noreferrer" :data-tip="packageDetail(p)?.reason">Website<svg aria-hidden="true"><use href="#ps-external"/></svg></a>
                                    </article>
                                </template>
                            </div>
                            <p class="ps-help" x-show="!packageSearching && packageSearched && !visiblePackages().length">Nothing found. Try another name or site.</p>
                            <p class="ps-help" x-show="packageOffline.length" x-text="'Not reachable right now: ' + packageOffline.join(', ') + '.'"></p>
                        </section>

                        <aside class="ps-packages-installed" :aria-label="modal==='plugins' ? 'Installed plugins' : 'Installed mods'">
                            <header>
                                <h3 class="ps-section-title" x-text="(modal==='plugins' ? 'Installed plugins' : 'Installed mods') + ' (' + (installed.items || []).length + ')'"></h3>
                                <span class="ps-badge" x-show="installed.context?.version" data-tip="Search results are matched to this version"><span x-text="packageTarget()"></span></span>
                            </header>
                            <ul class="ps-installed-list">
                                <template x-for="f in installed.items || []" :key="f.file">
                                    <li :class="{'is-off': !f.enabled}">
                                        <img :src="f.icon ? safeImage(f.icon) : boot.favicon_url" alt="" loading="lazy" :class="{'is-placeholder': !f.icon}">
                                        <div>
                                            <strong x-text="f.title"></strong>
                                            <small><span x-text="[versionLabel(f.version), f.label, f.enabled ? '' : 'Off', f.watch ? 'Checked at next start' : ''].filter(Boolean).join(' · ')"></span></small>
                                            <small class="ps-installed-failed" x-show="f.auto_off"><svg aria-hidden="true"><use href="#ps-alert"/></svg><span>Did not load, switched off</span><button type="button" class="ps-help-dot" x-show="canExplain()" x-on:click="explainPlugin(f.file)" :aria-label="'Ask the AI assistant why ' + f.title + ' did not load'" data-tip="Ask the AI assistant why"><svg aria-hidden="true"><use href="#ps-question"/></svg></button></small>
                                            <small class="ps-installed-reason" x-show="f.auto_off" x-text="f.auto_off"></small>
                                        </div>
                                        <button type="button" class="ps-switch" role="switch" :class="{'is-on': f.enabled}" :aria-checked="f.enabled" :aria-label="(f.enabled ? 'Turn off ' : 'Turn on ') + f.title" :data-tip="f.enabled ? 'On' : 'Off'" x-on:click="togglePackage(f)" :disabled="busy || status!=='offline'"></button>
                                        <div class="ps-installed-more" x-data="{open: false}" x-on:click.outside="open=false">
                                            <button type="button" class="ps-btn is-sm is-icon is-subtle" x-on:click="open=!open" :aria-expanded="open" :aria-label="'More for ' + f.title"><svg aria-hidden="true"><use href="#ps-dots"/></svg></button>
                                            <div class="ps-dropdown is-end ps-installed-menu" role="menu" x-show="open" x-transition.opacity>
                                                <button type="button" class="ps-menu-item" role="menuitem" x-show="f.key" x-on:click="open=false; installPackage({key: f.key, title: f.title, icon: f.icon, page: f.page}, true)" :disabled="busy || status!=='offline'"><svg aria-hidden="true"><use href="#ps-download"/></svg><span>Update</span></button>
                                                <a class="ps-menu-item" role="menuitem" x-show="safeLink(f.page) !== '#'" :href="safeLink(f.page)" target="_blank" rel="noopener noreferrer" x-on:click="open=false"><svg aria-hidden="true"><use href="#ps-external"/></svg><span x-text="'Open on ' + f.label"></span></a>
                                                <button type="button" class="ps-menu-item is-danger" role="menuitem" x-on:click="open=false; removePackage(f.file)" :disabled="busy || status!=='offline'"><svg aria-hidden="true"><use href="#ps-close"/></svg><span>Remove</span></button>
                                            </div>
                                        </div>
                                    </li>
                                </template>
                            </ul>
                            <p class="ps-help" x-show="!(installed.items || []).length" x-text="modal==='plugins' ? 'No plugins installed yet. Add one from the list.' : 'No mods installed yet. Add one from the list.'"></p>
                            <button type="button" class="ps-btn is-sm ps-folder-link" x-show="showWidget('files')" x-on:click="openPackageFolder()"><svg aria-hidden="true"><use href="#ps-files"/></svg><span x-text="'Open the ' + modal + ' folder'"></span></button>
                        </aside>
                    </div>
                </div>

                @if(\Simplify\Panel\Services\Extensions::web()) @include('server-directory::simplify.workspace') @endif

                {{-- Network --}}
                <div x-show="modal==='connection' && !loading">
                    <h3 class="ps-section-title">Server address</h3>
                    <p class="ps-help">Use this address to connect to your server.</p>
                    <button type="button" class="ps-btn ps-address" x-on:click="copyText(server.address)"><span x-text="server?.address || 'No address assigned'"></span><svg aria-hidden="true"><use href="#ps-copy"/></svg></button>
                    @if(\Simplify\Panel\Services\Subdomains::active())
                        <h3 class="ps-section-title">Subdomain</h3>
                        <p class="ps-help">Players can join with this name instead of the port address. The DNS records are created automatically; leave it empty to remove the subdomain.</p>
                        <label class="ps-field">Name
                            <span class="ps-input-row"><input x-model="requestedSubdomain" maxlength="63" placeholder="oak" x-on:keydown.enter.prevent="saveSubdomain()"><span class="ps-input-suffix" x-text="'.' + (advanced.subdomain?.domain || '')"></span><button type="button" class="ps-btn" x-on:click="saveSubdomain()" :disabled="busy || !server?.owner">Save</button></span>
                        </label>
                        <template x-if="subdomainStatus()">
                            <p class="ps-help"><span class="ps-badge" :class="subdomainStatus().tone"><i></i><span x-text="subdomainStatus().label"></span></span> <span x-text="advanced.subdomain?.message"></span></p>
                        </template>
                    @elseif(\Simplify\Panel\Services\Extensions::web()) @include('server-directory::simplify.subdomain') @endif
                </div>

                {{-- Server software (Minecraft): reinstall with another type, version or modpack. --}}
                <div x-show="modal==='software' && server?.minecraft && !loading">
                    <p class="ps-alert is-warn">Changing software reinstalls the server. A successful backup from the last 30 minutes is required. Stop the server and enter its name to confirm.</p>
                    <div class="ps-grid-2">
                        <label class="ps-field">Server type<select x-model="software.server_type"><option value="vanilla">Vanilla</option><option value="plus">Vanilla+</option><option value="modded">Modpack</option></select></label>
                        <label x-show="software.server_type!=='modded'" class="ps-field">Installed software
                            <select x-model.number="software.egg_id"><option value="">Choose software</option><template x-for="e in advanced.eggs || []" :key="e.id"><option :value="e.id" x-text="e.name"></option></template></select>
                        </label>
                        <label x-show="software.server_type!=='modded'" class="ps-field">Minecraft version<input x-model="software.minecraft_version" placeholder="1.21.3"></label>
                    </div>
                    <div x-show="software.server_type==='modded'">
                        <div class="ps-input-row">
                            <input class="ps-input" x-model="packQuery" placeholder="Search Modrinth, FTB, Technic…" x-on:keydown.enter="searchPacks()">
                            <button type="button" class="ps-btn" x-on:click="searchPacks()" :disabled="busy"><svg aria-hidden="true"><use href="#ps-search"/></svg>Search</button>
                        </div>
                        <div class="ps-package-grid">
                            <template x-for="p in packs" :key="p.key">
                                <button type="button" class="ps-package" x-on:click="selectPack(p)">
                                    <img :src="safeImage(p.icon_url)" alt="" loading="lazy">
                                    <span><strong x-text="p.title"></strong><small x-text="p.source"></small><p x-text="p.description"></p></span>
                                </button>
                            </template>
                        </div>
                        <label class="ps-field">Selected pack release
                            <select x-model="software.modpack_version"><option value="">Choose a release</option><template x-for="[id,name] in Object.entries(packReleases)" :key="id"><option :value="id" x-text="name"></option></template></select>
                        </label>
                    </div>
                    <label class="ps-field">Type the server name<input x-model="softwareConfirm" :placeholder="server?.name"></label>
                </div>
                <template x-if="modal==='software' && !server?.minecraft && server?.native_sections?.startup">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(server.native_sections.startup)" x-on:load="styleFrame($el, 'native')" title="Game startup settings"></iframe>
                </template>
                <template x-if="modal==='schedules' && server?.native_sections?.schedules">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(server.native_sections.schedules)" x-on:load="styleFrame($el, 'native')" title="Scheduled tasks"></iframe>
                </template>
                <template x-if="modal==='activity' && server?.native_sections?.activity">
                    <iframe data-ps-frame="native" :data-ps-accent="currentAccentHex()" :src="frameUrl(server.native_sections.activity)" x-on:load="styleFrame($el, 'native')" title="Activity log"></iframe>
                </template>

                {{-- Advanced --}}
                <div x-show="modal==='advanced' && !loading">
                    <div class="ps-action-wrap">
                        <a class="ps-btn" x-show="server?.permissions['database.read'] && server?.native_sections?.databases" :href="server?.native_sections?.databases" target="_blank" rel="noopener">Databases<svg aria-hidden="true"><use href="#ps-link"/></svg></a>
                        <a class="ps-btn" x-show="server?.root_admin && server?.permissions['user.read'] && server?.native_sections?.access" :href="server?.native_sections?.access" target="_blank" rel="noopener">Server access<svg aria-hidden="true"><use href="#ps-link"/></svg></a>
                    </div>
                    <h3 class="ps-section-title">Automatic runtime</h3>
                    <dl class="ps-kv">
                        <dt>Container image</dt><dd x-text="server?.image"></dd>
                        <dt>Startup command</dt><dd x-text="server?.startup"></dd>
                    </dl>
                    <p class="ps-help">Selected automatically. Only administrators can override these values.</p>
                    <section x-show="server?.owner" class="ps-danger-zone">
                        <h3 class="ps-section-title">Delete server</h3>
                        <p class="ps-help">Deletes this server and its files. This action cannot be undone.</p>
                        <label class="ps-field">Type the server name<input x-model="deleteConfirm" :placeholder="server?.name"></label>
                        <button type="button" class="ps-btn is-danger" x-on:click="deleteServer()" :disabled="busy || status!=='offline' || deleteConfirm!==server?.name">Delete server</button>
                    </section>
                </div>

                {{-- Scheduled restart --}}
                <div x-show="modal==='restart' && !loading">
                    <p class="ps-help">Choose when to stop, apply your staged settings, and start the server again.</p>
                    <label class="ps-field">Restart in · minutes<input type="number" min="1" max="10080" x-model.number="restartMinutes"></label>
                </div>
            </div>

            {{-- Footer actions belong to the open workspace. --}}
            <footer class="ps-modal-foot" x-show="['alias','background','settings','performance','software','restart'].includes(modal) && !loading && (modal!=='settings' || server?.minecraft) && (modal!=='performance' || server?.can_resources)">
                <span class="is-start" x-show="modal==='settings'" x-text="server?.pending ? 'Changes are waiting for a restart.' : 'Saved changes apply after a stop or restart.'"></span>
                <button type="button" class="ps-btn" x-on:click="close()" :disabled="busy">Cancel</button>
                <button type="button" class="ps-btn is-primary" x-show="modal==='alias'" x-on:click="saveAlias()" :disabled="busy">Save alias</button>
                <button type="button" class="ps-btn is-primary" x-show="modal==='background'" x-on:click="saveBackground()" :disabled="busy"><svg aria-hidden="true"><use href="#ps-check"/></svg><span x-text="busy ? 'Saving…' : 'Save background'"></span></button>
                <button type="button" class="ps-btn is-primary" x-show="modal==='settings'" x-on:click="saveSettings()" :disabled="busy || !server?.properties_available || !server?.permissions['file.update']">Save changes</button>
                <button type="button" class="ps-btn is-primary" x-show="modal==='performance'" x-on:click="saveSettings()" :disabled="busy">Save limits</button>
                <button type="button" class="ps-btn is-danger" x-show="modal==='software'" x-on:click="changeSoftware()" :disabled="busy || status!=='offline'">Install selected software</button>
                <button type="button" class="ps-btn is-primary" x-show="modal==='restart'" x-on:click="restartChanges(restartMinutes)" :disabled="busy"><svg aria-hidden="true"><use href="#ps-clock"/></svg>Schedule restart</button>
            </footer>
        </section>
    </div>

    {{-- Explain this error: the last console lines, explained in plain words by the AI an admin picked (with their own API key). --}}
    <div class="ps-modal-layer ps-explain-layer" :data-open="!!explain" x-show="explain" x-cloak x-on:click.self="closeExplain()" x-on:keydown.escape.stop="closeExplain()">
        <section class="ps-modal ps-explain" role="dialog" aria-modal="true" aria-labelledby="ps-explain-title" x-trap.noscroll="!!explain">
            <header class="ps-modal-head">
                <h2 id="ps-explain-title">Log check</h2>
                <button type="button" class="ps-btn is-sm is-icon is-subtle ps-close" x-on:click="closeExplain()" aria-label="Close"><svg aria-hidden="true"><use href="#ps-close"/></svg></button>
            </header>
            <div class="ps-modal-body" aria-live="polite">
                {{-- Root admins can also have the panel log and this node's Wings log explained. --}}
                <div class="ps-segmented ps-explain-sources" role="group" aria-label="What to explain" x-show="explainSources().length > 1">
                    <template x-for="source in explainSources()" :key="source">
                        <button type="button" :aria-pressed="explain?.source === source" :class="{'is-active': explain?.source === source}" :disabled="!!explain?.loading" x-on:click="explain?.source === source || explainError(source)" x-text="explainLabel(source)"></button>
                    </template>
                </div>
                <div x-show="explain?.loading" class="ps-modal-loading" role="status"><span class="ps-spinner"></span><span x-text="'Reading the last lines of the '+explainNoun(explain?.source)+'…'"></span></div>
                <div x-show="explain?.error" class="ps-explain-error" role="alert"><svg aria-hidden="true"><use href="#ps-alert"/></svg><p x-text="explain?.error"></p></div>
                {{-- First the check (everything seems in order, or what is wrong), then each problem or warning to open when you want to fix it. --}}
                <template x-if="explain?.answer">
                    <div class="ps-explain-answer" :class="{'is-fine': !explain.answer.found}">
                        <div class="ps-explain-verdict">
                            <svg aria-hidden="true"><use :href="explain.answer.found ? '#ps-alert' : '#ps-check'"/></svg>
                            <div><strong x-text="explain.answer.found ? 'Something needs attention' : 'Everything seems in order'"></strong><p x-show="explain.answer.summary" x-text="explain.answer.summary"></p></div>
                        </div>
                        <section x-show="explain.answer.issues.length">
                            <h3 x-text="explain.answer.found ? 'What was found' : 'Noticed something?'"></h3>
                            <template x-for="(issue, index) in explain.answer.issues" :key="index">
                                <details class="ps-explain-issue" :open="explain.answer.found && index === 0">
                                    <summary x-text="issue.title"></summary>
                                    <p x-show="issue.cause" x-text="issue.cause"></p>
                                    <ol x-show="issue.steps.length"><template x-for="(step, stepIndex) in issue.steps" :key="stepIndex"><li x-text="step"></li></template></ol>
                                </details>
                            </template>
                        </section>
                    </div>
                </template>
            </div>
            <footer class="ps-modal-foot">
                <span class="is-start" x-show="explain?.answer?.model" x-text="explain?.answer?.model ? 'Checked by '+explain.answer.model+' from the last '+explain.answer.lines+' lines of the '+explainNoun(explain.source)+'. Check before you delete anything.' : ''"></span>
                <button type="button" class="ps-btn" x-show="explain?.answer || explain?.error" x-on:click="explainError()" :disabled="!!explain?.loading"><svg aria-hidden="true"><use href="#ps-restart"/></svg>Ask again</button>
                <button type="button" class="ps-btn is-primary" x-on:click="closeExplain()">Done</button>
            </footer>
        </section>
    </div>
</div>
</x-filament-panels::page>
