<?php
declare(strict_types=1);
namespace Simplify\Panel\Services;
use App\Models\Server;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Storage;
/**
 * "Explain this error": the last console lines of a server, explained in plain words by Claude.
 * Optional: it only shows once a root admin saves their own Anthropic API key, and every question is paid
 * by that key. The key is stored encrypted and never leaves the server except to api.anthropic.com.
 */
final class ErrorExplainer
{
    public const FILE = 'simplify/error-explainer.json';
    public const ENDPOINT = 'https://api.anthropic.com/v1/messages';
    /** model id => label shown in Simplify settings. */
    public const MODELS = [
        'claude-opus-5-5' => 'Claude Opus 5.5 (best answers, a few cents)',
        'claude-sonnet-5-5' => 'Claude Sonnet 5.5 (about a cent)',
        'claude-haiku-5-5' => 'Claude Haiku 5.5 (cheapest)',
    ];
    public const AUDIENCES = ['everyone' => 'Everyone who can see the console', 'admins' => 'Administrators only'];
    /** Lines sent per question: Wings keeps at most 100 for its log endpoint. */
    public const LINES = 100;
    /** Questions per person per 10 minutes, and for the whole panel per day. */
    public const PER_USER = 6;
    public const PER_DAY = 200;
    /** Glob of the panel log files; storage/logs/*.log when null. */
    public static ?string $panelLogs = null;
    private const SCHEMA = ['type' => 'object', 'additionalProperties' => false, 'required' => ['found', 'summary', 'issues'], 'properties' => [
        'found' => ['type' => 'boolean', 'description' => 'True only when the log shows a real problem: a crash, a failed start or install, something that stops a feature, a player or the server from working. False for a normal log, also when it has harmless warnings.'],
        'summary' => ['type' => 'string', 'description' => 'One or two short sentences in plain words: what went wrong, or when found is false, that everything seems in order.'],
        'issues' => ['type' => 'array', 'description' => 'At most four. Real problems first, then warnings someone might still want to look at. Empty when there is nothing worth mentioning.', 'items' => [
            'type' => 'object', 'additionalProperties' => false, 'required' => ['title', 'cause', 'steps'], 'properties' => [
                'title' => ['type' => 'string', 'description' => 'A few words naming the problem. When found is false, phrase it as something the person may notice, for example "My panel feels slow" or "Players get disconnected".'],
                'cause' => ['type' => 'string', 'description' => 'What it means and the most likely cause, quoting the decisive log line or mod/plugin name when there is one. Say so when it is harmless.'],
                'steps' => ['type' => 'array', 'items' => ['type' => 'string'], 'description' => 'Up to five concrete things to try, most likely fix first. Empty when nothing needs to be done.'],
            ],
        ]],
    ]];
    private const SYSTEM = "You help people who run game servers (often Minecraft, sometimes other games) on a Pelican panel. "
        ."You get the last lines of a server's console, or for panel administrators the panel's own log or the Wings daemon log. First check whether anything is actually wrong, then explain it for someone who is not a developer: short, friendly sentences, no jargon without a short explanation. "
        ."Point at the line or the mod, plugin, file or setting that causes a problem when the log shows it. Suggest steps that can be done from a game panel: change a setting, remove or update a mod, restore a backup, give the server more memory, accept the EULA, check a file. For panel and Wings logs, steps an administrator can take on the panel or node machine are fine too. "
        ."Never invent details that are not in the log; say so when the log is not conclusive. Parts like [hidden] were removed for privacy. "
        ."Most logs are fine. Servers print many warnings that are normal and need no action: deprecation notices, \"Can't keep up!\", missing optional mods or config defaults, slow chunk loading, unknown or bad packets from scanner bots, players disconnecting, a single failed request or timeout that did not repeat (for example a few connection timeouts to Wings, such as cURL error 28, while everything else works), entries from hours or days ago that did not come back, and similar. "
        ."Set found to true only for a real problem: a crash, a failed start or install, an error that keeps repeating, or something that clearly stops the server, a feature or a player from working. "
        ."Otherwise set found to false and say that everything seems in order; list what the log does show as issues someone can open when they notice it (for example slow answers from Wings as \"My panel feels slow\"), and say when they are harmless. Answer in English.";

    /** ['model'=>..., 'audience'=>..., 'has_key'=>bool]; the key itself never leaves this class. */
    public static function settings(): array
    {
        $data = JsonFile::read(self::FILE);
        return ['model' => isset(self::MODELS[$data['model'] ?? null]) ? $data['model'] : array_key_first(self::MODELS), 'audience' => isset(self::AUDIENCES[$data['audience'] ?? null]) ? $data['audience'] : 'everyone', 'has_key' => is_string($data['key'] ?? null) && $data['key'] !== ''];
    }
    /** Saves the choices; an empty $key keeps the saved one, $remove forgets it. */
    public static function save(array $input, bool $remove = false): void
    {
        abort_unless(user()?->isRootAdmin(), 403);
        $current = JsonFile::read(self::FILE);
        $key = trim((string) ($input['key'] ?? ''));
        $next = [
            'model' => isset(self::MODELS[$input['model'] ?? null]) ? $input['model'] : self::settings()['model'],
            'audience' => isset(self::AUDIENCES[$input['audience'] ?? null]) ? $input['audience'] : self::settings()['audience'],
            'key' => $remove ? null : ($key !== '' ? encrypt($key) : ($current['key'] ?? null)),
        ];
        if (!Storage::disk('local')->put(self::FILE, json_encode($next, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT))) throw new \RuntimeException('Could not save the error explanation settings.');
    }
    private static function key(): ?string
    {
        $stored = JsonFile::read(self::FILE)['key'] ?? null;
        if (!is_string($stored) || $stored === '') return null;
        try { return (string) decrypt($stored); } catch (\Throwable) { return null; } // APP_KEY changed: ask for the key again.
    }
    /** Whether the signed-in user sees the button at all. */
    public static function availableFor($user): bool
    {
        if (!$user || !self::settings()['has_key']) return false;
        return self::settings()['audience'] === 'everyone' || $user->isAdmin();
    }

    /** Removes what should not leave the panel: addresses, e-mail addresses, tokens and passwords. */
    public static function sanitize(array $lines): array
    {
        $patterns = [
            '/\b(password|passwd|secret|token|api[_-]?key|authorization)(\s*[:=]\s*)\S+/i' => '$1$2[hidden]',
            '/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i' => '[hidden email]',
            '/\b(?:\d{1,3}\.){3}\d{1,3}\b/' => '[hidden ip]',
            '/\b(?:[0-9a-f]{1,4}:){3,7}[0-9a-f]{1,4}\b/i' => '[hidden ip]',
            '/\b(?=[A-Za-z0-9_\-]*\d)(?=[A-Za-z0-9_\-]*[A-Za-z])[A-Za-z0-9_\-]{32,}\b/' => '[hidden]',
        ];
        $clean = [];
        foreach ($lines as $line) {
            $line = preg_replace('/\x1b\[[0-9;?]*[ -\/]*[@-~]/', '', (string) $line) ?? '';
            $line = rtrim(preg_replace(array_keys($patterns), array_values($patterns), $line) ?? '');
            if ($line !== '') $clean[] = mb_substr($line, 0, 600);
        }
        return array_slice($clean, -self::LINES);
    }

    /** The Messages API request for these lines. */
    public static function payload(array $lines, string $model, string $context = ''): array
    {
        $payload = [
            'model' => $model,
            'max_tokens' => 8000,
            'system' => self::SYSTEM,
            'output_config' => ['effort' => 'low', 'format' => ['type' => 'json_schema', 'schema' => self::SCHEMA]],
            'messages' => [['role' => 'user', 'content' => ($context !== '' ? $context."\n" : '')."Log, oldest line first:\n<log>\n".implode("\n", $lines)."\n</log>\nIs everything working, or is something wrong here?"]],
        ];
        // Opus and Sonnet may decline a request that looks like a security topic; Anthropic then retries it on a fitting model.
        if ($model !== 'claude-haiku-5-5') $payload['fallbacks'] = 'default';
        return $payload;
    }
    /** Reads the answer from an API response body; null when there is no usable answer. */
    public static function answer(array $body): ?array
    {
        if (($body['stop_reason'] ?? null) === 'refusal') return null;
        foreach ((array) ($body['content'] ?? []) as $block) {
            if (($block['type'] ?? null) !== 'text') continue;
            $data = json_decode((string) ($block['text'] ?? ''), true);
            if (!is_array($data) || !is_string($data['summary'] ?? null)) continue;
            $issues = [];
            foreach (array_slice((array) ($data['issues'] ?? []), 0, 4) as $issue) {
                if (!is_array($issue) || trim((string) ($issue['title'] ?? '')) === '') continue;
                $issues[] = ['title' => trim((string) $issue['title']), 'cause' => trim((string) ($issue['cause'] ?? '')),
                    'steps' => array_values(array_slice(array_filter(array_map(fn ($s) => trim((string) $s), (array) ($issue['steps'] ?? [])), fn ($s) => $s !== ''), 0, 5))];
            }
            return ['found' => ($data['found'] ?? true) !== false, 'summary' => trim($data['summary']), 'issues' => $issues];
        }
        return null;
    }
    /** A short, plain message for a failed API call, never including the key. */
    public static function failure(int $status, array $body): string
    {
        $type = (string) ($body['error']['type'] ?? '');
        return match (true) {
            $status === 401 || $type === 'authentication_error' => 'The Anthropic API key is not valid. An administrator can enter a new one in Simplify settings.',
            $status === 403 || $type === 'permission_error' => 'This Anthropic API key may not use the chosen model. An administrator can pick another model in Simplify settings.',
            $status === 402 || str_contains(strtolower((string) ($body['error']['message'] ?? '')), 'credit') => 'The Anthropic account behind this key has no credit left. An administrator can add credit at console.anthropic.com.',
            $status === 429 || $type === 'rate_limit_error' => 'Anthropic is busy for this key right now. Try again in a minute.',
            $status === 529 || $type === 'overloaded_error' || $status >= 500 => 'Anthropic is temporarily unavailable. Try again in a minute.',
            default => 'Anthropic could not answer this question'.($status ? ' (error '.$status.')' : '').'. Try again later.',
        };
    }

    private static function call(string $key, array $payload): array
    {
        try {
            $headers = ['x-api-key' => $key, 'anthropic-version' => '2023-06-01'];
            if (isset($payload['fallbacks'])) $headers['anthropic-beta'] = 'server-side-fallback-2026-07-01';
            $response = Http::withHeaders($headers)
                ->acceptJson()->asJson()->connectTimeout(5)->timeout(90)->post(self::ENDPOINT, $payload);
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => 'Could not reach api.anthropic.com from the panel. Check that the panel server may connect to the internet.'];
        }
        $body = (array) ($response->json() ?? []);
        if (!$response->successful()) return ['ok' => false, 'error' => self::failure($response->status(), $body)];
        return ['ok' => true, 'body' => $body];
    }
    /** Settings "Test" button: a tiny request that proves the key and model work. */
    public static function test(?string $key = null, ?string $model = null): array
    {
        abort_unless(user()?->isRootAdmin(), 403);
        $key = trim((string) $key) ?: self::key();
        if (!$key) return ['ok' => false, 'message' => 'Enter an API key first.'];
        $model = isset(self::MODELS[$model]) ? $model : self::settings()['model'];
        $result = self::call($key, ['model' => $model, 'max_tokens' => 64, 'output_config' => ['effort' => 'low'], 'messages' => [['role' => 'user', 'content' => 'Reply with OK.']]]);
        return $result['ok'] ? ['ok' => true, 'message' => 'The key works with '.explode(' (', self::MODELS[$model])[0].'.'] : ['ok' => false, 'message' => preg_replace('/ An administrator .*$/', '', $result['error'])];
    }

    /** Where the lines come from: label for the popup, how the question introduces them, text when there are none. */
    public const SOURCES = [
        'console' => ['Console', null, 'The console is empty, so there is nothing to explain yet.'],
        'panel' => ['Panel log', 'Pelican panel log (Laravel), warnings and errors only, newest last.', 'The panel log has no warnings or errors right now.'],
        'wings' => ['Wings log', 'Wings daemon log of the node this server runs on', 'The Wings log of this node is empty.'],
    ];
    /** The panel log and the Wings log can hold anyone's details, so only root admins may send them. */
    public static function logsFor($user): bool
    {
        return (bool) ($user && self::settings()['has_key'] && $user->isRootAdmin());
    }
    /** The sources the signed-in user may explain, for a server page ($s) or the overview (null). */
    public static function sourcesFor($user, ?Server $s): array
    {
        $sources = [];
        if ($s && self::availableFor($user)) $sources[] = 'console';
        if (self::logsFor($user)) { $sources[] = 'panel'; if ($s) $sources[] = 'wings'; }
        return $sources;
    }

    /** The last console lines of a server, read from Wings (the same log the console shows). */
    public static function consoleLines(Server $s): array
    {
        $repository = app(\App\Repositories\Daemon\DaemonServerRepository::class)->setServer($s);
        if (in_array($s->status?->value, ['installing', 'install_failed', 'reinstall_failed'], true)) {
            return array_slice(preg_split('/\r?\n/', (string) $repository->getInstallLogs()) ?: [], -self::LINES);
        }
        return (array) ($repository->getHttpClient()->timeout(10)->get('/api/servers/'.$s->uuid.'/logs', ['size' => self::LINES])->throw()->json('data') ?? []);
    }
    /** The end of the newest panel log file. */
    public static function panelLogText(?string $pattern = null): string
    {
        $files = glob($pattern ?? self::$panelLogs ?? storage_path('logs').'/*.log') ?: [];
        if ($files === []) return '';
        usort($files, fn (string $a, string $b) => [filemtime($b), $b] <=> [filemtime($a), $a]);
        $file = new \SplFileObject($files[0], 'r');
        $size = $file->getSize();
        $file->fseek(max(0, $size - 262144));
        return $size > 0 ? (string) $file->fread(min($size, 262144)) : '';
    }
    /** Warnings and errors from a Laravel log: the last eight entries, each its message and first stack frames. */
    public static function panelEntries(string $text): array
    {
        $entries = preg_split('/\r?\n(?=\[\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})/', $text) ?: [];
        $wanted = array_values(array_filter($entries, fn (string $entry) => (bool) preg_match('/^\[[^\]]+\] [\w-]+\.(WARNING|ERROR|CRITICAL|ALERT|EMERGENCY):/', ltrim($entry))));
        $lines = [];
        foreach (array_slice($wanted, -8) as $entry) array_push($lines, ...array_slice(preg_split('/\r?\n/', trim($entry)) ?: [], 0, 12));
        return $lines;
    }
    /** The log part of a Wings diagnostics report (everything after its logs heading), last lines only. */
    public static function wingsLog(string $report): array
    {
        $lines = preg_split('/\r?\n/', $report) ?: [];
        foreach ($lines as $index => $line) {
            if (preg_match('/^\W*(latest\s+)?(wings\s+)?logs?\b/i', trim($line))) { $lines = array_slice($lines, $index + 1); break; }
        }
        return array_slice(array_values(array_filter($lines, fn ($line) => trim($line, " \t=-") !== '')), -self::LINES);
    }
    /** Where the question comes from, so Claude knows whether the panel itself is up. */
    public const ASKED_FROM = [
        'panel' => 'The panel itself is up: an administrator is using it to ask this.',
        'emergency' => "Asked from Simplify's emergency page, which works without the normal panel pages: the panel may be partly broken, for example showing error 500.",
        'terminal' => 'Asked from a terminal on the panel server: the panel website may be down.',
    ];
    private static function lines(?Server $s, string $source, $node = null): array
    {
        return match ($source) {
            'console' => self::consoleLines($s),
            'panel' => self::panelEntries(self::panelLogText()),
            'wings' => self::wingsLog((string) app(\App\Repositories\Daemon\DaemonSystemRepository::class)->setNode($node ?? $s->node)->getDiagnostics(self::LINES, false, true)->throw()->body()),
        };
    }
    /** The saved key for the emergency page and the terminal, which check access themselves. */
    public static function savedKey(): ?string
    {
        return self::key();
    }
    /** Runs $callback; when the cache or its store is broken (a half-working panel), $fallback instead of an error. */
    private static function guarded(callable $callback, mixed $fallback = null): mixed
    {
        try { return $callback(); } catch (\Throwable $e) { report($e); return $fallback; }
    }

    /** Explains a log for the signed-in user; answers stay cached a few minutes for the same lines. */
    public static function explain(?Server $s, string $source = 'console'): array
    {
        $user = user();
        if (!in_array($source, self::sourcesFor($user, $s), true) || !($key = self::key())) return ['ok' => false, 'error' => 'Error explanations are not set up on this panel.'];
        return self::ask($key, $source, $s, null, 'simplify.explain.user.'.$user->id, $source === 'console' ? '' : self::ASKED_FROM['panel']);
    }
    /**
     * The question itself, without access checks: explain() for the panel pages, the emergency page and
     * simplify:explain call it after checking who asks. $personal is the rate limit of one person (none in the terminal),
     * $limit the most lines sent and $asked one of ASKED_FROM.
     */
    public static function ask(string $key, string $source, ?Server $s = null, $node = null, ?string $personal = null, string $asked = '', int $limit = self::LINES): array
    {
        if (!isset(self::SOURCES[$source])) return ['ok' => false, 'error' => 'Unknown log.'];
        try { $lines = array_slice(self::sanitize(self::lines($s, $source, $node)), -max(1, min(self::LINES, $limit))); }
        catch (\Throwable $e) { report($e); return ['ok' => false, 'error' => $source === 'panel' ? 'Could not read the panel log.' : 'Could not read the '.($source === 'wings' ? 'Wings log' : 'console').' from Wings. Try again when the node is reachable.']; }
        if ($lines === []) return ['ok' => true, 'found' => false, 'summary' => self::SOURCES[$source][2], 'issues' => [], 'lines' => 0, 'model' => null, 'source' => $source];
        $settings = self::settings();
        $cacheKey = 'simplify.explain.'.sha1($settings['model'].$source.implode("\n", $lines));
        if (is_array($cached = self::guarded(fn () => Cache::get($cacheKey)))) return ['ok' => true, ...$cached];
        if ($personal && self::guarded(fn () => RateLimiter::tooManyAttempts($personal, self::PER_USER), false)) return ['ok' => false, 'error' => 'You asked a lot of questions in a short time. Try again in '.max(1, (int) ceil(RateLimiter::availableIn($personal) / 60)).' minute(s).'];
        if (self::guarded(fn () => RateLimiter::tooManyAttempts('simplify.explain.panel', self::PER_DAY), false)) return ['ok' => false, 'error' => 'This panel reached its daily limit of '.self::PER_DAY.' explanations. Try again tomorrow.'];
        self::guarded(function () use ($personal): void {
            if ($personal) RateLimiter::hit($personal, 600);
            RateLimiter::hit('simplify.explain.panel', 86400);
        });
        $context = self::SOURCES[$source][1] ?? ($s?->egg?->name ? 'Game or software: '.$s->egg->name : '');
        // The time lets Claude see that a warning from hours ago is not a problem now.
        $context = trim($context.($asked !== '' ? ' '.$asked : '')."\nCurrent time on the panel: ".date('Y-m-d H:i:s T'));
        $result = self::call($key, self::payload($lines, $settings['model'], $context));
        if (!$result['ok']) return $result;
        $answer = self::answer($result['body']);
        if (!$answer) return ['ok' => false, 'error' => 'Claude could not explain these lines. Try again after the error shows up again.'];
        $answer += ['lines' => count($lines), 'model' => explode(' (', self::MODELS[$settings['model']])[0], 'source' => $source];
        self::guarded(fn () => Cache::put($cacheKey, $answer, now()->addMinutes(10)));
        return ['ok' => true, ...$answer];
    }
}
